import sys
import glob
import asyncio
import logging
import importlib
import urllib3
from pathlib import Path

from config import CLIENTS, initialize_clients, CMD_HNDLR

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=logging.WARNING)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Store loaded plugin modules
LOADED_PLUGINS_MODULES = {}

def load_plugin_module(plugin_name):
    """Loads a plugin module without registering its handlers immediately."""
    if plugin_name in LOADED_PLUGINS_MODULES:
        return LOADED_PLUGINS_MODULES[plugin_name]

    path = Path(f"AltBots/modules/{plugin_name}.py")
    spec = importlib.util.spec_from_file_location(f"AltBots.modules.{plugin_name}", path)
    load = importlib.util.module_from_spec(spec)
    load.logger = logging.getLogger(plugin_name)
    spec.loader.exec_module(load)
    sys.modules["AltBots.modules." + plugin_name] = load
    LOADED_PLUGINS_MODULES[plugin_name] = load
    print("Altron has Imported " + plugin_name)
    return load

async def register_all_plugin_handlers():
    """Iterates through all active clients and loaded plugin modules
    to register their respective event handlers."""
    for client in CLIENTS:
        for plugin_name, module in LOADED_PLUGINS_MODULES.items():
            if hasattr(module, 'register_handlers'):
                try:
                    await module.register_handlers(client)
                    logging.info(f"Registered handlers for plugin '{plugin_name}' on client {client.session.name}.")
                except Exception as e:
                    logging.error(f"Error registering handlers for plugin '{plugin_name}' on client {client.session.name}: {e}")
            else:
                logging.warning(f"Plugin '{plugin_name}' does not have a 'register_handlers' function.")


print("\n𝐗𝐁𝐨𝐭𝐬 𝐃𝐞𝐩𝐥𝐨𝐲𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ⚡\nMy Master ---> @rajaraj909")

async def main():
    # 1. Load all plugin modules first
    files = glob.glob("AltBots/modules/*.py")
    for name in files:
        patt = Path(name)
        plugin_name = patt.stem
        if plugin_name == "__init__":
            continue
        load_plugin_module(plugin_name) # No .replace(".py", "") needed here if using Path.stem

    # 2. Initialize all Telegram clients
    await initialize_clients()

    # 3. After all clients are ready, register all event handlers for them
    await register_all_plugin_handlers()

    if CLIENTS:
        tasks = [client.run_until_disconnected() for client in CLIENTS]
        logging.info("All clients are running...")
        await asyncio.gather(*tasks)
    else:
        logging.error("No active clients found to run. Please check your BOT_TOKEN(s) in bot_tokens.json or env.")

if __name__ == "__main__":
    asyncio.run(main())