# main.py (no changes needed if bot_manager.py is in AltBots/modules/)
import sys
import glob
import asyncio
import logging
import importlib
import urllib3


from pathlib import Path
# Note: config.py now handles X1-X10 and CLIENTS dynamically
from config import CLIENTS, X1 # Just need CLIENTS and X1 for run_until_disconnected

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=logging.WARNING)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def load_plugins(plugin_name):
    path = Path(f"AltBots/modules/{plugin_name}.py")
    spec = importlib.util.spec_from_file_location(f"AltBots.modules.{plugin_name}", path)
    load = importlib.util.module_from_spec(spec)
    load.logger = logging.getLogger(plugin_name)
    spec.loader.exec_module(load)
    sys.modules["AltBots.modules." + plugin_name] = load
    print("Altron has Imported " + plugin_name)


files = glob.glob("AltBots/modules/*.py")
for name in files:
    with open(name) as a:
        patt = Path(a.name)
        plugin_name = patt.stem
        load_plugins(plugin_name.replace(".py", ""))

print("\n𝐗𝐁𝐨𝐭𝐬 𝐃𝐞𝐩𝐥𝐨𝐲𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ⚡\nMy Master ---> @rajaraj909")


async def main():
    # Run all successfully started clients concurrently
    tasks = [client.run_until_disconnected() for client in CLIENTS if client is not None]
    if tasks:
        await asyncio.gather(*tasks)
    else:
        print("No active Telegram clients to run.")

if __name__ == "__main__":
    asyncio.run(main())