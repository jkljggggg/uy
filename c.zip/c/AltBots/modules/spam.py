# © @ALONE_WAS_BOT
import asyncio

from AltBots.data import GROUP, PORMS
from config import ALL_CLIENTS, SUDO_USERS, CMD_HNDLR as hl

from random import choice
from telethon import events, functions, types

# Decorator for all clients
def on_all_clients(pattern):
    def decorator(func):
        for client in ALL_CLIENTS:
            client.on(events.NewMessage(incoming=True, pattern=pattern))(func)
        return func
    return decorator


async def gifspam(e, smex):
    try:
        await e.client(
            functions.messages.SaveGifRequest(
                id=types.InputDocument(
                    id=smex.media.document.id, # Fixed variable name here (was sandy)
                    access_hash=smex.media.document.access_hash,
                    file_reference=smex.media.document.file_reference,
                ),
                unsave=True,
            )
        )
    except Exception:
        pass


@on_all_clients(pattern=r"\%sspam(?: |$)(.*)" % hl)
async def spam(e):
    if e.sender_id in SUDO_USERS:
        text = e.text.split(" ", 2)
        if len(text) == 3:
            count = int(text[1])
            message = text[2]
            for _ in range(count):
                await e.client.send_message(e.chat_id, message)
                await asyncio.sleep(0.1) # Small delay to prevent flood waits
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}spam <𝐜𝐨𝐮𝐧𝐭> <𝐦𝐞𝐬𝐬𝐚𝐠𝐞>")


@on_all_clients(pattern=r"\%sdspam(?: |$)(.*)" % hl)
async def dspam(e):
    if e.sender_id in SUDO_USERS:
        text = e.text.split(" ", 2)
        if len(text) == 3:
            count = int(text[1])
            message = text[2]
            for _ in range(count):
                m = await e.client.send_message(e.chat_id, message)
                await m.delete()
                await asyncio.sleep(0.1) # Small delay to prevent flood waits
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}dspam <𝐜𝐨𝐮𝐧𝐭> <𝐦𝐞𝐬𝐬𝐚𝐠𝐞>")


@on_all_clients(pattern=r"\%sgspam(?: |$)(.*)" % hl)
async def gspam(e):
    if e.sender_id in SUDO_USERS:
        if e.reply_to_msg_id:
            reply_msg = await e.get_reply_message()
            if reply_msg.media and hasattr(reply_msg.media, 'document') and reply_msg.media.document.mime_type.startswith('video/mp4'):
                text = e.text.split(" ", 1)
                if len(text) == 2:
                    count = int(text[1])
                    for _ in range(count):
                        await e.client.send_file(e.chat_id, reply_msg.media)
                        await asyncio.sleep(0.1) # Small delay
                else:
                    await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}gspam <𝐜𝐨𝐮𝐧𝐭> <𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐠𝐢𝐟>")
            else:
                await e.reply("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ɢɪꜰ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}gspam <𝐜𝐨𝐮𝐧𝐭> <𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐠𝐢𝐟>")


@on_all_clients(pattern=r"\%svspam(?: |$)(.*)" % hl)
async def vspam(e):
    if e.sender_id in SUDO_USERS:
        if e.reply_to_msg_id:
            reply_msg = await e.get_reply_message()
            if reply_msg.media and hasattr(reply_msg.media, 'document') and reply_msg.media.document.mime_type.startswith('video/'):
                text = e.text.split(" ", 1)
                if len(text) == 2:
                    count = int(text[1])
                    for _ in range(count):
                        await e.client.send_file(e.chat_id, reply_msg.media)
                        await asyncio.sleep(0.1) # Small delay
                else:
                    await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}vspam <𝐜𝐨𝐮𝐧𝐭> <𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐯𝐢𝐝𝐞𝐨>")
            else:
                await e.reply("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴠɪᴅᴇᴏ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}vspam <𝐜𝐨𝐮𝐧𝐭> <𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐯𝐢𝐝𝐞𝐨>")


@on_all_clients(pattern=r"\%sall(?: |$)(.*)" % hl)
async def mention_all(event):
    if event.sender_id in SUDO_USERS:
        if not event.is_group:
            await event.reply("» ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ ᴡᴏʀᴋꜱ ɪɴ ɢʀᴏᴜᴘꜱ.")
            return

        chat = await event.get_chat()
        members = []
        async for user in event.client.iter_participants(chat):
            if not user.bot:
                members.append(f"[{user.first_name}](tg://user?id={user.id})")
        
        if not members:
            await event.reply("» ɴᴏ ᴜꜱᴇʀꜱ ꜰᴏᴜɴᴅ ᴛᴏ ᴍᴇɴᴛɪᴏɴ.")
            return

        mentions = ""
        for i, member in enumerate(members):
            mentions += member + " "
            if (i + 1) % 5 == 0:  # Mention 5 users per message
                await event.client.send_message(event.chat_id, mentions)
                mentions = ""
                await asyncio.sleep(0.5) # Small delay between messages
        
        if mentions: # Send remaining mentions
            await event.client.send_message(event.chat_id, mentions)


@on_all_clients(pattern=r"\%sp(?: |$)(.*)" % hl)
async def porms(e):
    if e.sender_id in SUDO_USERS:
        text = e.text.split(" ", 2)
        if len(text) == 3:
            count = int(text[1])
            message = text[2]
            for _ in range(count):
                await e.client.send_message(e.chat_id, choice(PORMS) + "\n" + message)
                await asyncio.sleep(0.1)
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}p <𝐜𝐨𝐮𝐧𝐭> <𝐦𝐞𝐬𝐬𝐚𝐠𝐞>")


@on_all_clients(pattern=r"\%sgp(?: |$)(.*)" % hl)
async def group_porms(e):
    if e.sender_id in SUDO_USERS:
        text = e.text.split(" ", 2)
        if len(text) == 3:
            count = int(text[1])
            message = text[2]
            for _ in range(count):
                await e.client.send_message(e.chat_id, choice(GROUP) + "\n" + message)
                await asyncio.sleep(0.1)
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}gp <𝐜𝐨𝐮𝐧𝐭> <𝐦𝐞𝐬𝐬𝐚𝐠𝐞>")