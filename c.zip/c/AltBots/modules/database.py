import sqlite3
import logging

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=logging.WARNING)

DATABASE_NAME = 'bot_data.db'

def init_db():
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS bot_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT NOT NULL UNIQUE
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sudo_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL UNIQUE
        )
    ''')
    conn.commit()
    conn.close()

def add_bot_token(token):
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO bot_tokens (token) VALUES (?)", (token,))
        conn.commit()
        logging.info(f"Bot token added to DB: {token}")
        return True
    except sqlite3.IntegrityError:
        logging.warning(f"Bot token already exists in DB: {token}")
        return False
    finally:
        conn.close()

def get_bot_tokens():
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT token FROM bot_tokens")
    tokens = [row[0] for row in cursor.fetchall()]
    conn.close()
    return tokens

def remove_bot_token(token):
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM bot_tokens WHERE token = ?", (token,))
    conn.commit()
    conn.close()
    logging.info(f"Bot token removed from DB: {token}")

def add_sudo_user(user_id):
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO sudo_users (user_id) VALUES (?)", (user_id,))
        conn.commit()
        logging.info(f"Sudo user added to DB: {user_id}")
        return True
    except sqlite3.IntegrityError:
        logging.warning(f"Sudo user already exists in DB: {user_id}")
        return False
    finally:
        conn.close()

def get_sudo_users():
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM sudo_users")
    users = [row[0] for row in cursor.fetchall()]
    conn.close()
    return users

def remove_sudo_user(user_id):
    conn = sqlite3.connect(DATABASE_NAME)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM sudo_users WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()
    logging.info(f"Sudo user removed from DB: {user_id}")

if __name__ == '__main__':
    init_db()
    # Example usage:
    # add_bot_token("YOUR_NEW_BOT_TOKEN_HERE")
    # add_sudo_user(123456789)
    # print(get_bot_tokens())
    # print(get_sudo_users())