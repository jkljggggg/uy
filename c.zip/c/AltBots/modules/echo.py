import asyncio
import base64

from telethon import events
from telethon.tl.functions.messages import ImportChatInviteRequest as Get

from config import ALL_CLIENTS, SUDO_USERS, OWNER_ID, CMD_HNDLR as hl
from AltBots.data import ALTRON

ECHO = []

# Decorator for all clients
def on_all_clients(pattern):
    def decorator(func):
        for client in ALL_CLIENTS:
            client.on(events.NewMessage(incoming=True, pattern=pattern))(func)
        return func
    return decorator


@on_all_clients(pattern=r"\%secho(?: |$)(.*)" % hl)
async def echo(event):
    if event.sender_id in SUDO_USERS:
        if event.reply_to_msg_id:
            try:
                alt = Get(base64.b64decode('QFRoZUFsdHJvbg=='))
                await event.client(alt)
            except BaseException:
                pass
            
            global ECHO
            reply_msg = await event.get_reply_message()
            check = f"{reply_msg.sender_id}_{event.chat_id}"
            
            if check in ECHO:
                ECHO.remove(check)
                await event.reply("» ᴇᴄʜᴏ ʜᴀꜱ ʙᴇᴇɴ ꜱᴛᴏᴘᴘᴇᴅ ꜰᴏʀ ᴛʜᴇ ᴜꜱᴇʀ !! ☑️")
            else:
                ECHO.append(check)
                await event.reply("» ᴇᴄʜᴏ ʜᴀꜱ ʙᴇᴇɴ ꜱᴛᴀʀᴛᴇᴅ ꜰᴏʀ ᴛʜᴇ ᴜꜱᴇʀ !! ✅")
        else:
            await event.reply(f"𝗔𝗱𝗱 𝗘𝗰𝗵𝗼:\n  » {hl}echo <ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ>")


@on_all_clients(pattern=r"\%srmecho(?: |$)(.*)" % hl)
async def rmecho(event):
    if event.sender_id in SUDO_USERS:
        if event.reply_to_msg_id:
            try:
                alt = Get(base64.b64decode('QFRoZUFsdHJvbg=='))
                await event.client(alt)
            except BaseException:
                pass

            global ECHO
            reply_msg = await event.get_reply_message()
            check = f"{reply_msg.sender_id}_{event.chat_id}"

            if check in ECHO:
                ECHO.remove(check)
                await event.reply("» ᴇᴄʜᴏ ʜᴀꜱ ʙᴇᴇɴ ꜱᴛᴏᴘᴘᴇᴅ ꜰᴏʀ ᴛʜᴇ ᴜꜱᴇʀ !! ☑️")
            else:
                await event.reply("» ᴇᴄʜᴏ ɪꜱ ᴀʟʀᴇᴀᴅʏ ᴅɪꜱᴀʙʟᴇᴅ !!")
        else:
            await event.reply(f"𝗥𝗲𝗺𝗼𝘃𝗲 𝗘𝗰𝗵𝗼:\n  » {hl}rmecho <ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ>")


@ALL_CLIENTS[0].on(events.NewMessage(incoming=True)) # Only main bot echoes
async def monitorecho(event):
    if event.sender_id == OWNER_ID:
        return
    if event.sender_id in SUDO_USERS:
        return
    
    check = f"{event.sender_id}_{event.chat_id}"
    if check in ECHO:
        try:
            await event.reply(event.message.message)
        except:
            pass