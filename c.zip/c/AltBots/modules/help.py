from telethon import events, Button

from config import X1, SUDO_USERS, CMD_HNDLR as hl


HELP_STRING = f"★  𝙃𝙚𝙡𝙥 𝙈𝙚𝙣𝙪 ★\n\n» **ᴄʟɪᴄᴋ ᴏɴ ʙᴇʟᴏᴡ ʙᴜᴛᴛᴏɴꜱ ꜰᴏʀ ʜᴇʟᴘ**\n» **ᴅᴇᴠᴇʟᴏᴘᴇʀ: @RAJARAJ909**"

HELP_BUTTON = [
    [
      Button.inline("• ꜱᴘᴀᴍ •", data="spam"),
      Button.inline("• ʀᴀɪᴅ •", data="raid")
    ],
    [
      Button.inline("• ᴇxᴛʀᴀ •", data="extra")
    ],
    [
      Button.url("• ᴄʜᴀɴɴᴇʟ •", "https://t.me/terabaaplowde"),
      Button.url("• sᴜᴘᴘᴏʀᴛ •", "https://t.me/djdjdjznsnsn")
    ]
  ]


@X1.on(events.NewMessage(incoming=True, pattern=r"\%shelp(?: |$)(.*)" % hl))
async def help(event):
    if event.sender_id in SUDO_USERS:
        await event.reply(HELP_STRING, buttons=HELP_BUTTON)
    else:
        await event.reply("Make Your Own Altron Bots !! @RAJARAJ909")


spam_msg = """
**ꜱᴘᴀᴍ ʜᴇʟᴘ ᴍᴇɴᴜ**

**ᴄᴏᴍᴍᴀɴᴅꜱ**:
» **.spam** <ᴄᴏᴜɴᴛ> <ᴛᴇxᴛ>
» **.spam** <ᴄᴏᴜɴᴛ> <ʀᴇᴘʟʏ ᴛᴏ ᴍᴇꜱꜱᴀɢᴇ>
» **.pspam** <ᴄᴏᴜɴᴛ>
» **.hang** <ᴄᴏᴜɴᴛ>
"""

raid_msg = """
**ʀᴀɪᴅ ʜᴇʟᴘ ᴍᴇɴᴜ**

**ᴄᴏᴍᴍᴀɴᴅꜱ**:
» **.raid** <ᴄᴏᴜɴᴛ> <ᴜꜱᴇʀɴᴀᴍᴇ>
» **.raid** <ᴄᴏᴜɴᴛ> <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ>
» **.mraid** <ᴄᴏᴜɴᴛ> <ᴜꜱᴇʀɴᴀᴍᴇ>
» **.mraid** <ᴄᴏᴜɴᴛ> <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ>
» **.sraid** <ᴄᴏᴜɴᴛ> <ᴜꜱᴇʀɴᴀᴍᴇ>
» **.sraid** <ᴄᴏᴜɴᴛ> <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ>
» **.craid** <ᴄᴏᴜɴᴛ> <ᴜꜱᴇʀɴᴀᴍᴇ>
» **.craid** <ᴄᴏᴜɴᴛ> <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ>
» **.rraid** <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ>
» **.rmrraid** <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ>
"""

extra_msg = """
**ᴇxᴛʀᴀ ʜᴇʟᴘ ᴍᴇɴᴜ**

**ᴄᴏᴍᴍᴀɴᴅꜱ**:
» **.ping**
» **.echo** <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ>
» **.rmecho** <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ>
» **.leave** <ᴄʜᴀᴛ ɪᴅ>
» **.addsudo** <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ / ᴜꜱᴇʀɴᴀᴍᴇ / ɪᴅ>
» **.removesudo** <ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ / ᴜꜱᴇʀɴᴀᴍᴇ / ɪᴅ>
» **.addbot** <ʙᴏᴛ_ᴛᴏᴋᴇɴ> (ᴏɴʟʏ ᴏᴡɴᴇʀ)
» **.removebot** <ʙᴏᴛ_ɴᴀᴍᴇ> (ᴏɴʟʏ ᴏᴡɴᴇʀ)
"""

@X1.on(events.CallbackQuery(pattern=r"help_back"))
async def help_back(event):
    if event.query.user_id in SUDO_USERS:
        await event.edit(HELP_STRING, buttons=HELP_BUTTON)
    else:
        await event.answer("Make Your Own Altron Bots !! @RAJARAJ909", cache_time=0, alert=True)


@X1.on(events.CallbackQuery(pattern=r"spam"))
async def help_spam(event):
    if event.query.user_id in SUDO_USERS:
        await event.edit(spam_msg,
            buttons=[[Button.inline("< Back", data="help_back"),],],
          )
    else:
        await event.answer("Make Your Own Altron Bots !! @RAJARAJ909", cache_time=0, alert=True)


@X1.on(events.CallbackQuery(pattern=r"raid"))
async def help_raid(event):
    if event.query.user_id in SUDO_USERS:
        await event.edit(raid_msg,
            buttons=[[Button.inline("< Back", data="help_back"),],],
          )
    else:
        await event.answer("Make Your Own Altron Bots !! @RAJARAJ909", cache_time=0, alert=True)


@X1.on(events.CallbackQuery(pattern=r"extra"))
async def help_extra(event):
    if event.query.user_id in SUDO_USERS:
        await event.edit(extra_msg,
            buttons=[[Button.inline("< Back", data="help_back"),],],
          )
    else:
        await event.answer("Make Your Own Altron Bots !! @RAJARAJ909", cache_time=0, alert=True)