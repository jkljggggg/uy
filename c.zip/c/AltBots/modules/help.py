from telethon import events, Button

from config import SUDO_USERS, CMD_HNDLR as hl # No X1, X2 imports needed

HELP_STRING = f"★  𝙃𝙚𝙡𝙥 𝙈𝙚𝙣𝙪 ★\n\n» **ᴄʟɪᴄᴋ ᴏɴ ʙᴇʟᴏᴡ ʙᴜᴛᴛᴏɴꜱ ꜰᴏʀ ʜᴇʟᴘ**\n» **ᴅᴇᴠᴇʟᴏᴘᴇʀ: @RAJARAJ909**"

HELP_BUTTON = [
    [
      Button.inline("• ꜱᴘᴀᴍ •", data="spam"),
      Button.inline("• ʀᴀɪᴅ •", data="raid")
    ],
    [
      Button.inline("• ᴇxᴛʀᴀ •", data="extra")
    ],
    [
      Button.url("• ᴄʜᴀɴɴᴇʟ •", "https://t.me/terabaaplowde"),
      Button.url("• sᴜᴘᴘᴏʀᴛ •", "https://t.me/djdjdjznsnsn")
    ]
  ]

spam_msg = f"** Spam Cmds **\n\n**» {hl}spam <count> <text>**\n» {hl}bigspam <count> <text>\n» {hl}delayspam <delay> <count> <text>\n» {hl}randspam <count> <text>"
raid_msg = f"** Raid Cmds **\n\n**» {hl}raid <reply to user>**\n» {hl}craid <reply to user>\n» {hl}sraid <reply to user>\n» {hl}mraid <reply to user>\n» {hl}draid <reply to user>\n» {hl}delraid <reply to user>"
extra_msg = f"** Extra Cmds **\n\n**» {hl}ping**\n» {hl}addsudo <reply/userid>\n» {hl}delsudo <reply/userid>\n» {hl}addbot <token>\n» {hl}delbot <token/index>\n» {hl}listbots\n» {hl}restart\n» {hl}leave <group id>\n» {hl}delbot <token>"

# --- Command Handlers ---

async def help_command(event):
    if event.sender_id in SUDO_USERS:
        await event.reply(
            HELP_STRING,
            buttons=HELP_BUTTON,
            link_preview=False
        )
    else:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ ᴄᴀɴ ᴜꜱᴇ ᴛʜɪꜱ.")


async def help_back(event):
    if event.query.user_id in SUDO_USERS:
        await event.edit(
            HELP_STRING,
            buttons=HELP_BUTTON,
            link_preview=False
        )
    else:
        await event.answer("Make Your Own Altron Bots !! @RAJARAJ909", cache_time=0, alert=True)

async def help_spam(event):
    if event.query.user_id in SUDO_USERS:
        await event.edit(spam_msg,
            buttons=[[Button.inline("< Back", data="help_back"),],],
          )
    else:
        await event.answer("Make Your Own Altron Bots !! @RAJARAJ909", cache_time=0, alert=True)

async def help_raid(event):
    if event.query.user_id in SUDO_USERS:
        await event.edit(raid_msg,
            buttons=[[Button.inline("< Back", data="help_back"),],],
          )
    else:
        await event.answer("Make Your Own Altron Bots !! @RAJARAJ909", cache_time=0, alert=True)

async def help_extra(event):
    if event.query.user_id in SUDO_USERS:
        await event.edit(extra_msg,
            buttons=[[Button.inline("< Back", data="help_back"),],],
          )
    else:
        await event.answer("Make Your Own Altron Bots !! @RAJARAJ909", cache_time=0, alert=True)

# --- Registration Function for main.py ---

async def register_handlers(client):
    """Registers all handlers for a given TelegramClient instance."""
    client.add_event_handler(help_command, events.NewMessage(incoming=True, pattern=r"\%shelp(?: |$)(.*)" % hl))
    client.add_event_handler(help_back, events.CallbackQuery(pattern=b"help_back"))
    client.add_event_handler(help_spam, events.CallbackQuery(pattern=b"spam"))
    client.add_event_handler(help_raid, events.CallbackQuery(pattern=b"raid"))
    client.add_event_handler(help_extra, events.CallbackQuery(pattern=b"extra"))