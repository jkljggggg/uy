import asyncio
import heroku3
from os import getenv, execl
import sys

from telethon import events

from config import X1, OWNER_ID, HEROKU_API_KEY, HEROKU_APP_NAME, CMD_HNDLR as hl

@X1.on(events.NewMessage(incoming=True, pattern=r"\%saddbot(?: |$)(.*)" % hl))
async def add_new_bot(event):
    if event.sender_id == OWNER_ID:
        ok = await event.reply("» __Adding new bot...__")
        token_input = event.pattern_match.group(1).strip()

        if not token_input:
            await ok.edit("» Please provide a bot token. Usage: `.addbot <BOT_TOKEN>`")
            return

        if HEROKU_APP_NAME is None or HEROKU_API_KEY is None:
            await ok.edit("`[HEROKU]:` `\nPlease set HEROKU_APP_NAME and HEROKU_API_KEY in your Heroku config vars.`")
            return

        try:
            Heroku = heroku3.from_key(HEROKU_API_KEY)
            app = Heroku.app(HEROKU_APP_NAME)
            heroku_var = app.config()

            # Find the next available BOT_TOKEN slot
            for i in range(1, 11): # Assuming up to BOT_TOKEN10
                token_key = f"BOT_TOKEN{i}" if i > 1 else "BOT_TOKEN"
                if heroku_var.get(token_key) is None:
                    heroku_var[token_key] = token_input
                    await ok.edit(f"» Successfully added new bot to `{token_key}`. Restarting...")
                    await asyncio.sleep(2)
                    execl(sys.executable, sys.executable, *sys.argv)
                    return
            await ok.edit("» All bot token slots (BOT_TOKEN to BOT_TOKEN10) are already occupied. Remove an existing bot first.")

        except Exception as e:
            await ok.edit(f"Error adding bot: `{str(e)}`")

@X1.on(events.NewMessage(incoming=True, pattern=r"\%sremovebot(?: |$)(.*)" % hl))
async def remove_existing_bot(event):
    if event.sender_id == OWNER_ID:
        ok = await event.reply("» __Removing bot...__")
        token_number_input = event.pattern_match.group(1).strip()

        if not token_number_input:
            await ok.edit("» Please provide the bot token number to remove (e.g., `1` for BOT_TOKEN, `2` for BOT_TOKEN2). Usage: `.removebot <NUMBER>`")
            return

        try:
            token_number = int(token_number_input)
            if not (1 <= token_number <= 10):
                await ok.edit("» Invalid bot token number. Please provide a number between 1 and 10.")
                return

            token_key_to_remove = f"BOT_TOKEN{token_number}" if token_number > 1 else "BOT_TOKEN"

            if HEROKU_APP_NAME is None or HEROKU_API_KEY is None:
                await ok.edit("`[HEROKU]:` `\nPlease set HEROKU_APP_NAME and HEROKU_API_KEY in your Heroku config vars.`")
                return

            Heroku = heroku3.from_key(HEROKU_API_KEY)
            app = Heroku.app(HEROKU_APP_NAME)
            heroku_var = app.config()

            if heroku_var.get(token_key_to_remove) is None:
                await ok.edit(f"» No bot token found for `{token_key_to_remove}`.")
                return

            del heroku_var[token_key_to_remove]
            await ok.edit(f"» Successfully removed bot from `{token_key_to_remove}`. Restarting...")
            await asyncio.sleep(2)
            execl(sys.executable, sys.executable, *sys.argv)

        except ValueError:
            await ok.edit("» Invalid token number. Please provide a number.")
        except Exception as e:
            await ok.edit(f"Error removing bot: `{str(e)}`")