from telethon import __version__, events, Button

from config import X1


START_BUTTON = [
    [
        Button.inline("• ᴄᴏᴍᴍᴀɴᴅs •", data="help_back")
    ],
    [
        Button.url("• ᴄʜᴀɴɴᴇʟ •", "https://t.me/terabaaplowde"),
        Button.url("• sᴜᴘᴘᴏʀᴛ •", "https://t.me/djdjdjznsnsn")
    ],
    [
        Button.url("• ʀᴇᴘᴏ •", "https://files.catbox.moe/k3q4k0.jpg")
    ]
]


@X1.on(events.NewMessage(pattern="/start"))
async def start(event):              
    if event.is_private:
        AltBot = await event.client.get_me()
        bot_name = AltBot.first_name
        bot_id = AltBot.id
        TEXT = f"**ʜᴇʏ​ [{event.sender.first_name}](tg://user?id={event.sender.id}),\n\nɪ ᴀᴍ [{bot_name}](tg://user?id={bot_id}) ᴀ ᴘᴏᴡᴇʀꜰᴜʟ ᴛᴇʟᴇɢʀᴀᴍ ʙᴏᴛ ʙᴜɪʟᴛ ᴛᴏ ᴍᴀɴᴀɢᴇ ʏᴏᴜʀ ɢʀᴏᴜᴘꜱ ᴀɴᴅ ᴄʜᴀɴɴᴇʟꜱ ᴡɪᴛʜ ᴇᴀꜱᴇ.\n\nɪ ᴀᴍ ᴄᴜʀʀᴇɴᴛʟʏ ᴡᴏʀᴋɪɴɢ ᴏɴ {len(event.client.iter_dialogs())} ᴄʜᴀᴛꜱ.\n\n⚡ ᴘᴏᴡᴇʀᴇᴅ ʙʏ: @RAJARAJ909\n\n"
        await event.reply(TEXT, buttons=START_BUTTON)
    else:
        await event.reply("ɪ ᴀᴍ ᴀʟɪᴠᴇ ⚡")