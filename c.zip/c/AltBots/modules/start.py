from telethon import __version__, events, Button

from config import ALL_CLIENTS


START_BUTTON = [
    [
        Button.inline("• ᴄᴏᴍᴍᴀɴᴅs •", data="help_back")
    ],
    [
        Button.url("• ᴄʜᴀɴɴᴇʟ •", "https://t.me/terabaaplowde"),
        Button.url("• sᴜᴘᴘᴏʀᴛ •", "https://t.me/djdjdjznsnsn")
    ],
    [
        Button.url("• ʀᴇᴘᴏ •", "https://files.catbox.moe/k3q4k0.jpg")
    ]
]

# Decorator for all clients
def on_all_clients(pattern):
    def decorator(func):
        for client in ALL_CLIENTS:
            client.on(events.NewMessage(pattern=pattern))(func)
        return func
    return decorator


@on_all_clients(pattern="/start")
async def start(event):              
    if event.is_private:
        AltBot = await event.client.get_me()
        bot_name = AltBot.first_name
        bot_id = AltBot.id
        TEXT = f"**ʜᴇʏ​ [{event.sender.first_name}](tg://user?id={event.sender.id}),\n\nɪ ᴀᴍ [{bot_name}](tg://user?id={bot_id}) ᴀ ᴘᴏᴡᴇʀꜰᴜʟʟ ᴛᴇʟᴇɢʀᴀᴍ ʙᴏᴛ ᴛᴏ ᴍᴀɴᴀɢᴇ ʏᴏᴜʀ ɢʀᴏᴜᴘ ᴀɴᴅ ᴘʀᴏꜰɪʟᴇ.\n\n⚡ ᴠᴇʀꜱɪᴏɴ : {__version__}\n"
        await event.client.send_file(
            event.chat_id,
            "https://telegra.ph/file/0950346a152d19b78e24c.jpg",
            caption=TEXT,
            buttons=START_BUTTON
        )