import asyncio

from config import ALL_CLIENTS, SUDO_USERS, OWNER_ID, CMD_HNDLR as hl

from datetime import datetime

from telethon import events
from telethon.errors import ForbiddenError

# Decorator for all clients
def on_all_clients(pattern):
    def decorator(func):
        for client in ALL_CLIENTS:
            client.on(events.NewMessage(incoming=True, pattern=pattern))(func)
        return func
    return decorator
 
@on_all_clients(pattern=r"\%slogs(?: |$)(.*)" % hl)
async def logs(legend):
    if legend.sender_id == OWNER_ID:
        await legend.reply("» 𝐇𝐞𝐫𝐨𝐤𝐮 𝐢𝐧𝐭𝐞𝐠𝐫𝐚𝐭𝐢𝐨𝐧 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐫𝐞𝐦𝐨𝐯𝐞𝐝.\n» 𝐁𝐨𝐭 𝐥𝐨𝐠𝐬 𝐚𝐫𝐞 𝐧𝐨 𝐥𝐨𝐧𝐠𝐞𝐫 𝐚𝐯𝐚𝐢𝐥𝐚𝐛𝐥𝐞 𝐯𝐢𝐚 𝐭𝐡𝐢𝐬 𝐜𝐨𝐦𝐦𝐚𝐧𝐝.")
    else:
        await legend.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴛʜᴇ ᴏᴡɴᴇʀ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")