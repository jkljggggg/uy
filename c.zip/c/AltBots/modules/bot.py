import sys
import json
import asyncio
from os import execl
from datetime import datetime
from telethon import events

from config import SUDO_USERS, OWNER_ID, CMD_HNDLR as hl, SUDO_USERS_FILE, BOT_TOKENS_FILE, BOT_TOKENS, initialize_clients, CLIENTS

# Function to save sudo users to file
def save_sudo_users():
    with open(SUDO_USERS_FILE, "w") as f:
        json.dump(sorted(list(set(SUDO_USERS))), f, indent=4)

# Function to save bot tokens to file
def save_bot_tokens():
    with open(BOT_TOKENS_FILE, "w") as f:
        json.dump(BOT_TOKENS, f, indent=4)

# --- Command Handlers ---

async def ping(event):
    if event.sender_id in SUDO_USERS:
        start_time = datetime.now()
        await event.reply("ᴘᴏɴɢ❗")
        end_time = datetime.now()
        ping_time = (end_time - start_time).microseconds / 1000
        await event.edit(f"ᴘᴏɴɢ❗ `{ping_time}ms`")
    else:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ ᴄᴀɴ ᴜꜱᴇ ᴛʜɪꜱ.")

async def addsudo(event):
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ᴀᴅᴅ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ.")
        return

    ok = await event.reply("» ᴘʀᴏᴄᴇꜱꜱɪɴɢ...")
    user_id = None
    user_name = None

    if event.reply_to_msg_id:
        reply_message = await event.get_reply_message()
        user_id = reply_message.sender_id
        user_name = reply_message.sender.first_name
    elif event.pattern_match.group(1):
        user_input = event.pattern_match.group(1).strip()
        try:
            user_id = int(user_input)
            user = await event.client.get_entity(user_id)
            user_name = user.first_name
        except ValueError:
            try:
                user = await event.client.get_entity(user_input)
                user_id = user.id
                user_name = user.first_name
            except Exception:
                await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ᴜꜱᴇʀɴᴀᴍᴇ.")
                return
        except Exception:
            await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ᴜꜱᴇʀɴᴀᴍᴇ.")
            return
    else:
        await ok.edit(f"» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ɢɪᴠᴇ ᴛʜᴇɪʀ ᴜꜱᴇʀ ɪᴅ/ᴜꜱᴇʀɴᴀᴍᴇ ᴛᴏ ᴀᴅᴅ ᴀꜱ ꜱᴜᴅᴏ.")
        return

    if user_id in SUDO_USERS:
        await ok.edit(f"» [{user_name}](tg://user?id={user_id}) ɪꜱ ᴀʟʀᴇᴀᴅʏ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ.")
    else:
        SUDO_USERS.append(user_id)
        save_sudo_users()
        await ok.edit(f"» [{user_name}](tg://user?id={user_id}) ʜᴀꜱ ʙᴇᴇɴ ᴀᴅᴅᴇᴅ ᴀꜱ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ. ✅")

async def delsudo(event):
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ʀᴇᴍᴏᴠᴇ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ.")
        return

    ok = await event.reply("» ᴘʀᴏᴄᴇꜱꜱɪɴɢ...")
    user_id = None
    user_name = None

    if event.reply_to_msg_id:
        reply_message = await event.get_reply_message()
        user_id = reply_message.sender_id
        user_name = reply_message.sender.first_name
    elif event.pattern_match.group(1):
        user_input = event.pattern_match.group(1).strip()
        try:
            user_id = int(user_input)
            user = await event.client.get_entity(user_id)
            user_name = user.first_name
        except ValueError:
            try:
                user = await event.client.get_entity(user_input)
                user_id = user.id
                user_name = user.first_name
            except Exception:
                await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ᴜꜱᴇʀɴᴀᴍᴇ.")
                return
        except Exception:
            await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ᴜꜱᴇʀɴᴀᴍᴇ.")
            return
    else:
        await ok.edit(f"» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ɢɪᴠᴇ ᴛʜᴇɪʀ ᴜꜱᴇʀ ɪᴅ/ᴜꜱᴇʀɴᴀᴍᴇ ᴛᴏ ʀᴇᴍᴏᴠᴇ ᴀꜱ ꜱᴜᴅᴏ.")
        return

    if user_id == OWNER_ID:
        await ok.edit("» ʏᴏᴜ ᴄᴀɴɴᴏᴛ ʀᴇᴍᴏᴠᴇ ᴛʜᴇ ᴏᴡɴᴇʀ ꜰʀᴏᴍ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ.")
    elif user_id not in SUDO_USERS:
        await ok.edit(f"» [{user_name}](tg://user?id={user_id}) ɪꜱ ɴᴏᴛ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ.")
    else:
        SUDO_USERS.remove(user_id)
        save_sudo_users()
        await ok.edit(f"» [{user_name}](tg://user?id={user_id}) ʜᴀꜱ ʙᴇᴇɴ ʀᴇᴍᴏᴠᴇᴅ ꜰʀᴏᴍ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ. ✅")

async def restart_bot(event): # Renamed to avoid conflict with `restart` system call
    if event.sender_id == OWNER_ID:
        ok = await event.reply("» ʀᴇꜱᴛᴀʀᴛɪɴɢ...")
        await asyncio.sleep(1) # Give time for the message to send
        try:
            # This restart command will relaunch main.py
            execl(sys.executable, sys.executable, sys.argv[0])
        except Exception as e:
            await ok.edit(f"» ꜰᴀɪʟᴇᴅ ᴛᴏ ʀᴇꜱᴛᴀʀᴛ: `{str(e)}`")
    else:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ʀᴇꜱᴛᴀʀᴛ ᴛʜᴇ ʙᴏᴛ.")

async def add_bot_token(event):
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ᴀᴅᴅ ʙᴏᴛꜱ.")
        return

    token = event.pattern_match.group(1).strip()
    if not token:
        await event.reply("» ᴘʟᴇᴀꜱᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ʙᴏᴛ ᴛᴏᴋᴇɴ.")
        return

    if token in BOT_TOKENS:
        await event.reply("» ᴛʜɪꜱ ʙᴏᴛ ᴛᴏᴋᴇɴ ɪꜱ ᴀʟʀᴇᴀᴅʏ ᴀᴅᴅᴇᴅ.")
        return

    BOT_TOKENS.append(token)
    save_bot_tokens()
    await event.reply("» ʙᴏᴛ ᴛᴏᴋᴇɴ ᴀᴅᴅᴇᴅ. ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛ ᴛᴏ ᴀᴘᴘʟʏ ᴄʜᴀɴɢᴇꜱ...")
    await asyncio.sleep(2)
    try:
        execl(sys.executable, sys.executable, sys.argv[0]) # Relaunch main.py
    except Exception as e:
        await event.reply(f"» ꜰᴀɪʟᴇᴅ ᴛᴏ ʀᴇꜱᴛᴀʀᴛ: `{str(e)}`")

async def del_bot_token(event):
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ʀᴇᴍᴏᴠᴇ ʙᴏᴛꜱ.")
        return

    token_or_index = event.pattern_match.group(1).strip()
    if not token_or_index:
        await event.reply("» ᴘʟᴇᴀꜱᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ʙᴏᴛ ᴛᴏᴋᴇɴ ᴏʀ ɪɴᴅᴇx ᴛᴏ ʀᴇᴍᴏᴠᴇ. Use `.listbots` to see indices.")
        return

    removed = False
    
    # Try removing by exact token match first
    if token_or_index in BOT_TOKENS:
        BOT_TOKENS.remove(token_or_index)
        save_bot_tokens()
        removed = True
    else:
        # Try removing by index
        try:
            index_to_remove = int(token_or_index) - 1 # User sees 1-based index
            if 0 <= index_to_remove < len(BOT_TOKENS):
                removed_token = BOT_TOKENS.pop(index_to_remove)
                save_bot_tokens()
                await event.reply(f"» ʙᴏᴛ (ɪɴᴅᴇx {index_to_remove + 1}) ᴡɪᴛʜ ᴛᴏᴋᴇɴ `{removed_token[:5]}...` ʀᴇᴍᴏᴠᴇᴅ. ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛ ᴛᴏ ᴀᴘᴘʟʏ ᴄʜᴀɴɢᴇꜱ...")
                removed = True
            else:
                await event.reply("» ɪɴᴠᴀʟɪᴅ ʙᴏᴛ ɪɴᴅᴇx.")
        except ValueError:
            await event.reply("» ɪɴᴠᴀʟɪᴅ ʙᴏᴛ ᴛᴏᴋᴇɴ ᴏʀ ɪɴᴅᴇx. ᴘʟᴇᴀꜱᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴠᴀʟɪᴅ ᴛᴏᴋᴇɴ ᴏʀ ɪɴᴅᴇx.")

    if removed:
        await asyncio.sleep(2)
        try:
            execl(sys.executable, sys.executable, sys.argv[0]) # Relaunch main.py
        except Exception as e:
            await event.reply(f"» ꜰᴀɪʟᴇᴅ ᴛᴏ ʀᴇꜱᴛᴀʀᴛ: `{str(e)}`")
    else:
        await event.reply("» ʙᴏᴛ ᴛᴏᴋᴇɴ ᴏʀ ɪɴᴅᴇx ɴᴏᴛ ꜰᴏᴜɴᴅ.")

async def list_bots(event):
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ʟɪꜱᴛ ʙᴏᴛꜱ.")
        return

    if not BOT_TOKENS:
        await event.reply("» ɴᴏ ʙᴏᴛ ᴛᴏᴋᴇɴꜱ ᴀʀᴇ ᴄᴏɴꜰɪɢᴜʀᴇᴅ.")
        return

    message = "**★ ᴄᴏɴꜰɪɢᴜʀᴇᴅ ʙᴏᴛ ᴛᴏᴋᴇɴꜱ: ★**\n\n"
    for i, token in enumerate(BOT_TOKENS):
        # Find the corresponding client in the CLIENTS list
        found_client = None
        for client in CLIENTS:
            # We assume the client's session name might indicate its origin, or we get its ID
            # It's better to get the bot's user ID directly from the token on startup
            # For now, we'll try to match by position if possible, or just list the token
            try:
                # Get the bot's own user ID if the client is active
                client_info = await client.get_me()
                if client_info and client_info.bot: # Ensure it's a bot
                    # This is tricky because we don't have the token directly linked to the client object
                    # A better way would be to store (token, client_obj) pairs in CLIENTS.
                    # For now, we'll assume CLIENTS are in the same order as BOT_TOKENS for display.
                    if i < len(CLIENTS) and CLIENTS[i] == client: # Simple positional match for display
                         message += f"**{i+1}.** Token: `{token[:5]}...` | ID: `{client_info.id}` | Username: @`{client_info.username or 'N/A'}`\n"
                         break # Found the client for this token
            except Exception:
                # Client might not be connected or fetching info failed
                pass
        else: # If loop completes without break, client not found or not active in CLIENTS list by position
            message += f"**{i+1}.** Token: `{token[:5]}...` | Status: `Not Active / Failed to get info`\n"

    await event.reply(message)


# --- Registration Function for main.py ---

async def register_handlers(client):
    """Registers all handlers for a given TelegramClient instance."""
    client.add_event_handler(ping, events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
    client.add_event_handler(addsudo, events.NewMessage(incoming=True, pattern=r"\%saddsudo(?: |$)(.*)" % hl))
    client.add_event_handler(delsudo, events.NewMessage(incoming=True, pattern=r"\%sdelsudo(?: |$)(.*)" % hl))
    client.add_event_handler(restart_bot, events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
    client.add_event_handler(add_bot_token, events.NewMessage(incoming=True, pattern=r"\%saddbot(?: |$)(.*)" % hl))
    client.add_event_handler(del_bot_token, events.NewMessage(incoming=True, pattern=r"\%sdelbot(?: |$)(.*)" % hl))
    client.add_event_handler(list_bots, events.NewMessage(incoming=True, pattern=r"\%slistbots(?: |$)(.*)" % hl))