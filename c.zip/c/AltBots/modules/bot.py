import sys
# heroku3 and related imports removed as Heroku is no longer used

from config import ALL_CLIENTS, OWNER_ID, SUDO_USERS, CMD_HNDLR as hl, add_bot_token, remove_bot_token, add_sudo_user, remove_sudo_user, API_ID, API_HASH # Added API_ID, API_HASH

from os import execl, getenv
from telethon import events, TelegramClient # Added TelegramClient for dynamic bot adding
from datetime import datetime
import asyncio # Added for asyncio.sleep and dynamic client management


# Decorator for all clients
def on_all_clients(pattern):
    def decorator(func):
        for client in ALL_CLIENTS:
            client.on(events.NewMessage(incoming=True, pattern=pattern))(func)
        return func
    return decorator


@on_all_clients(pattern=r"\%sping(?: |$)(.*)" % hl)
async def ping(event):
    if event.sender_id in SUDO_USERS:
        start = datetime.now()
        hmm = await event.reply("`𝐏𝐎𝐍𝐆!`")
        end = datetime.now()
        ms = (end - start).microseconds / 1000
        await hmm.edit(f"𝐏𝐎𝐍𝐆!⚡\n`{ms} ms`")


@on_all_clients(pattern=r"\%saddsudo(?: |$)(.*)" % hl)
async def addsudo_cmd(event): # Renamed to avoid conflict with imported function
    if event.sender_id == OWNER_ID:
        ok = await event.reply(f"» __ᴀᴅᴅɪɴɢ ᴜꜱᴇʀ ᴀꜱ ꜱᴜᴅᴏ...__")
        target_id = None
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            target_id = reply_msg.sender_id
        elif event.pattern_match.group(1):
            try:
                target_id = int(event.pattern_match.group(1))
            except ValueError:
                await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ !!")
                return

        if target_id is None:
            await ok.edit("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴜꜱᴇʀ ɪᴅ !!")
            return

        if add_sudo_user(target_id): # Use the database function
            SUDO_USERS.append(target_id) # Update in-memory list
            await ok.edit(f"» ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ᴀᴅᴅᴇᴅ `{target_id}` ᴀꜱ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ !!\n\n**❗ ɴᴏᴛᴇ:** ᴛʜɪꜱ ᴄʜᴀɴɢᴇ ɪꜱ ᴘᴇʀꜱɪꜱᴛᴇɴᴛ.")
        else:
            await ok.edit(f"» ᴜꜱᴇʀ ɪꜱ ᴀʟʀᴇᴀᴅʏ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ !!")
    else:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴛʜᴇ ᴏᴡɴᴇʀ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")


@on_all_clients(pattern=r"\%sremsudo(?: |$)(.*)" % hl)
async def remsudo_cmd(event): # Renamed to avoid conflict with imported function
    if event.sender_id == OWNER_ID:
        ok = await event.reply(f"» __ʀᴇᴍᴏᴠɪɴɢ ᴜꜱᴇʀ ꜰʀᴏᴍ ꜱᴜᴅᴏ...__")
        target_id = None
        if event.reply_to_msg_id:
            reply_msg = await event.get_reply_message()
            target_id = reply_msg.sender_id
        elif event.pattern_match.group(1):
            try:
                target_id = int(event.pattern_match.group(1))
            except ValueError:
                await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ !!")
                return

        if target_id is None:
            await ok.edit("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴜꜱᴇʀ ɪᴅ !!")
            return

        if target_id not in SUDO_USERS:
            await ok.edit(f"» ᴜꜱᴇʀ ɪꜱ ɴᴏᴛ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ !!")
        elif target_id == OWNER_ID:
            await ok.edit(f"» ʏᴏᴜ ᴄᴀɴɴᴏᴛ ʀᴇᴍᴏᴠᴇ ᴛʜᴇ ᴏᴡɴᴇʀ ꜰʀᴏᴍ ꜱᴜᴅᴏ !!")
        else:
            remove_sudo_user(target_id) # Use the database function
            SUDO_USERS.remove(target_id) # Update in-memory list
            await ok.edit(f"» ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ʀᴇᴍᴏᴠᴇᴅ `{target_id}` ꜰʀᴏᴍ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ !!\n\n**❗ ɴᴏᴛᴇ:** ᴛʜɪꜱ ᴄʜᴀɴɢᴇ ɪꜱ ᴘᴇʀꜱɪꜱᴛᴇɴᴛ.")
    else:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴛʜᴇ ᴏᴡɴᴇʀ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")


@on_all_clients(pattern=r"\%ssudolist(?: |$)(.*)" % hl)
async def sudolist(event):
    if event.sender_id in SUDO_USERS:
        sudo_users_str = "\n".join([f"- `{user_id}`" for user_id in SUDO_USERS])
        await event.reply(f"**⚡ Sudo Users List ⚡**\n\n{sudo_users_str}")


@on_all_clients(pattern=r"\%saddbot(?: |$)(.*)" % hl)
async def add_new_bot(event):
    if event.sender_id == OWNER_ID:
        token = event.pattern_match.group(1).strip()
        if not token:
            await event.reply("» 𝐏𝐥𝐞𝐚𝐬𝐞 𝐩𝐫𝐨𝐯𝐢𝐝𝐞 𝐚 𝐛𝐨𝐭 𝐭𝐨𝐤𝐞𝐧 𝐭𝐨 𝐚𝐝𝐝. \n𝐔𝐬𝐚𝐠𝐞: `.addbot <bot_token>`")
            return

        status_msg = await event.reply(f"» 𝐀𝐭𝐭𝐞𝐦𝐩𝐭𝐢𝐧𝐠 𝐭𝐨 𝐚𝐝𝐝 𝐛𝐨𝐭 𝐰𝐢𝐭𝐡 𝐭𝐨𝐤𝐞𝐧: `{token[:5]}...`")

        if add_bot_token(token): # Add to database
            try:
                # Try to start the new client dynamically
                new_client_name = f'X{len(ALL_CLIENTS) + 1}'
                new_client = TelegramClient(new_client_name, API_ID, API_HASH)
                await new_client.start(bot_token=token)
                ALL_CLIENTS.append(new_client) # Add to in-memory list
                
                # Register all existing handlers for the new client
                for plugin_name in sys.modules:
                    if plugin_name.startswith("AltBots.modules."):
                        module = sys.modules[plugin_name]
                        for attr_name in dir(module):
                            attr = getattr(module, attr_name)
                            if hasattr(attr, '__name__') and attr.__name__ == 'decorator_wrapper': # Check if it's our decorator's wrapped func
                                if hasattr(attr, '__wrapped__'): # Get the original decorated function
                                    original_func = attr.__wrapped__
                                    # Manually apply the pattern
                                    if hasattr(original_func, '_pattern'):
                                        new_client.on(events.NewMessage(incoming=True, pattern=original_func._pattern))(original_func)

                await status_msg.edit(f"» 𝐁𝐨𝐭 𝐬𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 𝐚𝐝𝐝𝐞𝐝 𝐚𝐧𝐝 𝐬𝐭𝐚𝐫𝐭𝐞𝐝!\n\n**❗ 𝐍𝐨𝐭𝐞:** 𝐓𝐡𝐢𝐬 𝐛𝐨𝐭 𝐰𝐢𝐥𝐥 𝐛𝐞 𝐚𝐜𝐭𝐢𝐯𝐞 𝐮𝐧𝐭𝐢𝐥 𝐫𝐞𝐬𝐭𝐚𝐫𝐭. 𝐅𝐨𝐫 𝐩𝐞𝐫𝐬𝐢𝐬𝐭𝐞𝐧𝐜𝐞 𝐨𝐧 𝐫𝐞𝐬𝐭𝐚𝐫𝐭, 𝐢𝐭 𝐡𝐚𝐬 𝐛𝐞𝐞𝐧 𝐬𝐚𝐯𝐞𝐝 𝐭𝐨 𝐭𝐡𝐞 𝐝𝐚𝐭𝐚𝐛𝐚𝐬𝐞.")
                # Run the new client in the background
                asyncio.create_task(new_client.run_until_disconnected())

            except Exception as e:
                remove_bot_token(token) # Remove from DB if failed to start
                await status_msg.edit(f"» 𝐅𝐚𝐢𝐥𝐞𝐝 𝐭𝐨 𝐬𝐭𝐚𝐫𝐭 𝐛𝐨𝐭 𝐰𝐢𝐭𝐡 𝐭𝐨𝐤𝐞𝐧 `{token[:5]}...`: {e}\n» 𝐓𝐨𝐤𝐞𝐧 𝐫𝐞𝐦𝐨𝐯𝐞𝐝 𝐟𝐫𝐨𝐦 𝐝𝐚𝐭𝐚𝐛𝐚𝐬𝐞.")
        else:
            await status_msg.edit(f"» 𝐁𝐨𝐭 𝐭𝐨𝐤𝐞𝐧 `{token[:5]}...` 𝐚𝐥𝐫𝐞𝐚𝐝𝐲 𝐞𝐱𝐢𝐬𝐭𝐬 𝐢𝐧 𝐭𝐡𝐞 𝐝𝐚𝐭𝐚𝐛𝐚𝐬𝐞.")
    else:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴛʜᴇ ᴏᴡɴᴇʀ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")


@on_all_clients(pattern=r"\%srembot(?: |$)(.*)" % hl)
async def remove_bot(event):
    if event.sender_id == OWNER_ID:
        token_prefix = event.pattern_match.group(1).strip()
        if not token_prefix:
            await event.reply("» 𝐏𝐥𝐞𝐚𝐬𝐞 𝐩𝐫𝐨𝐯𝐢𝐝𝐞 𝐚 𝐛𝐨𝐭 𝐭𝐨𝐤𝐞𝐧 (𝐨𝐫 𝐚 𝐩𝐚𝐫𝐭𝐢𝐚𝐥 𝐭𝐨𝐤𝐞𝐧) 𝐭𝐨 𝐫𝐞𝐦𝐨𝐯𝐞. \n𝐔𝐬𝐚𝐠𝐞: `.rembot <bot_token_prefix>`")
            return

        status_msg = await event.reply(f"» 𝐀𝐭𝐭𝐞𝐦𝐩𝐭𝐢𝐧𝐠 𝐭𝐨 𝐫𝐞𝐦𝐨𝐯𝐞 𝐛𝐨𝐭 𝐰𝐢𝐭𝐡 𝐭𝐨𝐤𝐞𝐧 𝐩𝐫𝐞𝐟𝐢𝐱: `{token_prefix}`")

        removed_count = 0
        bots_to_remove = []

        # Find clients to remove based on partial token match (be careful with this!)
        for client in ALL_CLIENTS[1:]: # Skip the main bot (X1)
            if client.is_connected() and client.me and client.me.bot and client.me.bot_token and client.me.bot_token.startswith(token_prefix):
                bots_to_remove.append(client)

        if not bots_to_remove:
            await status_msg.edit(f"» 𝐍𝐨 𝐚𝐜𝐭𝐢𝐯𝐞 𝐛𝐨𝐭𝐬 𝐟𝐨𝐮𝐧𝐝 𝐰𝐢𝐭𝐡 𝐭𝐨𝐤𝐞𝐧 𝐩𝐫𝐞𝐟𝐢𝐱 `{token_prefix}`.")
            return

        for client_to_remove in bots_to_remove:
            token = client_to_remove.me.bot_token
            remove_bot_token(token) # Remove from database
            
            # Disconnect the client
            await client_to_remove.disconnect()
            
            # Remove from ALL_CLIENTS list (careful with iteration while modifying)
            if client_to_remove in ALL_CLIENTS:
                ALL_CLIENTS.remove(client_to_remove)
            
            removed_count += 1
            logging.info(f"Removed bot with token: {token[:5]}...")

        await status_msg.edit(f"» 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 𝐫𝐞𝐦𝐨𝐯𝐞𝐝 {removed_count} 𝐛𝐨𝐭(𝐬) 𝐰𝐢𝐭𝐡 𝐭𝐨𝐤𝐞𝐧 𝐩𝐫𝐞𝐟𝐢𝐱 `{token_prefix}`.")
    else:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴛʜᴇ ᴏᴡɴᴇʀ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")


@on_all_clients(pattern=r"\%sbotlist(?: |$)(.*)" % hl)
async def botlist(event):
    if event.sender_id in SUDO_USERS:
        if not ALL_CLIENTS:
            await event.reply("» 𝐍𝐨 𝐛𝐨𝐭𝐬 𝐚𝐫𝐞 𝐜𝐮𝐫𝐫𝐞𝐧𝐭𝐥𝐲 𝐚𝐜𝐭𝐢𝐯𝐞.")
            return

        bot_info = []
        for i, client in enumerate(ALL_CLIENTS):
            try:
                me = await client.get_me()
                status = "Online" if client.is_connected() else "Offline"
                bot_info.append(f"• **{me.first_name}** (`{me.id}`) - **Status:** `{status}`")
            except Exception as e:
                bot_info.append(f"• 𝐁𝐨𝐭 {i+1} (Error: {e}) - Status: `Offline`")
        
        bot_list_str = "\n".join(bot_info)
        await event.reply(f"**⚡ 𝐀𝐜𝐭𝐢𝐯𝐞 𝐁𝐨𝐭𝐬 𝐋𝐢𝐬𝐭 ⚡**\n\n{bot_list_str}")


@on_all_clients(pattern=r"\%srestart(?: |$)(.*)" % hl)
async def restart_cmd(event): # Renamed to avoid conflict with future potential global restart function
    if event.sender_id == OWNER_ID:
        await event.reply("» ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛꜱ... ɪᴛ ᴡɪʟʟ ᴛᴀᴋᴇ ᴀ ꜰᴇᴡ ꜱᴇᴄᴏɴᴅꜱ.")
        execl(sys.executable, sys.executable, "-m", "AltBots")
    else:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴛʜᴇ ᴏᴡɴᴇʀ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ.")