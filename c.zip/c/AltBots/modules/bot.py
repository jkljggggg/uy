import sys
# import heroku3 # Removed, as per your request

from config import X1, X2, X3, X4, X5, X6, X7, X8, X9, X10, OWNER_ID, SUDO_USERS, CMD_HNDLR as hl
# Removed HEROKU_APP_NAME, HEROKU_API_KEY from config import as they are not needed for these specific commands now

from os import execl, getenv
from telethon import events
from datetime import datetime


@X1.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
@X2.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
@X3.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
@X4.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
@X5.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
@X6.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
@X7.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
@X8.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
@X9.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
@X10.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
async def ping(event):
    if event.sender_id in SUDO_USERS:
        start = datetime.now()
        hmm = await event.reply("» ᴘɪɴɢɪɴɢ...")
        end = datetime.now()
        ms = (end - start).microseconds / 1000
        await hmm.edit(f"» ᴘᴏɴɢ❗❕\n» `{ms}` ᴍꜱ")


# Modified addsudo to only work with X1 and OWNER_ID, and without Heroku interaction
@X1.on(events.NewMessage(incoming=True, pattern=r"\%ssudo(?: |$)(.*)" % hl))
async def addsudo(event):
    if event.sender_id == OWNER_ID:
        ok = await event.reply(f"» __ᴀᴅᴅɪɴɢ ᴜꜱᴇʀ ᴀꜱ ꜱᴜᴅᴏ...__")
        target = ""
        try:
            reply_msg = await event.get_reply_message()
            target = reply_msg.sender_id
        except AttributeError: # Catches if no reply message
            await ok.edit("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ !!")
            return

        # Ensure SUDO_USERS is a list (it should be from config.py)
        if target in SUDO_USERS:
            await ok.edit(f"» ᴛʜɪꜱ ᴜꜱᴇʀ ɪꜱ ᴀʟʀᴇᴀᴅʏ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ !!")
        else:
            SUDO_USERS.append(target)
            await ok.edit(f"» ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ᴀᴅᴅᴇᴅ {target} ᴀꜱ ꜱᴜᴅᴏ !!\n__Changes will be lost on restart unless manually added to config.__")

# New removesudo command without Heroku interaction
@X1.on(events.NewMessage(incoming=True, pattern=r"\%srmsudo(?: |$)(.*)" % hl))
async def removesudo(event):
    if event.sender_id == OWNER_ID:
        ok = await event.reply(f"» __ʀᴇᴍᴏᴠɪɴɢ ᴜꜱᴇʀ ꜰʀᴏᴍ ꜱᴜᴅᴏ...__")
        target = ""
        try:
            reply_msg = await event.get_reply_message()
            target = reply_msg.sender_id
        except AttributeError: # Catches if no reply message
            await ok.edit("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ !!")
            return

        if target in SUDO_USERS:
            SUDO_USERS.remove(target)
            await ok.edit(f"» ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ʀᴇᴍᴏᴠᴇᴅ {target} ꜰʀᴏᴍ ꜱᴜᴅᴏ !!\n__Changes will be lost on restart unless manually removed from config.__")
        else:
            await ok.edit(f"» ᴛʜɪꜱ ᴜꜱᴇʀ ɪꜱ ɴᴏᴛ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ !!")


@X1.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
@X2.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
@X3.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
@X4.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
@X5.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
@X6.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
@X7.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
@X8.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
@X9.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
@X10.on(events.NewMessage(incoming=True, pattern=r"\%srestart(?: |$)(.*)" % hl))
async def restart(event):
    if event.sender_id == OWNER_ID:
        await event.reply("» __ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛ...__")
        try:
            execl(sys.executable, sys.executable, *sys.argv)
        except Exception as e:
            await event.reply(f"Error: {e}")