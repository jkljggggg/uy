import asyncio

from config import X1, OWNER_ID, SUDO_USERS, CMD_HNDLR as hl

from os import execl, getenv
from telethon import events
from datetime import datetime

ACTIVE_BOT_TOKENS = {}
BOT_CLIENTS = {
    'X1': X1
}

@X1.on(events.NewMessage(incoming=True, pattern=r"\%sping(?: |$)(.*)" % hl))
async def ping(event):
    start = datetime.now()
    ok = await event.reply("» __ᴘᴏɴɢ❗__")
    end = datetime.now()
    ms = (end - start).microseconds / 1000
    await ok.edit(f"» **ᴘᴏɴɢ❗**\n» `{ms}` ms")

@X1.on(events.NewMessage(incoming=True, pattern=r"\%saddbot(?: |$)(.*)" % hl))
async def add_bot(event):
    if event.sender_id == OWNER_ID:
        args = event.text.split(None, 1)
        if len(args) == 2:
            bot_token = args[1].strip()
            new_bot_name = f"X{len(BOT_CLIENTS) + 1}"
            ACTIVE_BOT_TOKENS[new_bot_name] = bot_token
            await event.reply(f"» Bot with token `{bot_token}` added as `{new_bot_name}`. "
                              "**Restart the private bot for changes to take effect.** (Simulated)")
        else:
            await event.reply("» Usage: `.addbot <bot_token>`")
    else:
        await event.reply("» Only the owner can use this command.")

@X1.on(events.NewMessage(incoming=True, pattern=r"\%sremovebot(?: |$)(.*)" % hl))
async def remove_bot(event):
    if event.sender_id == OWNER_ID:
        args = event.text.split(None, 1)
        if len(args) == 2:
            bot_name = args[1].strip().upper()
            if bot_name in ACTIVE_BOT_TOKENS:
                del ACTIVE_BOT_TOKENS[bot_name]
                await event.reply(f"» Bot `{bot_name}` removed. "
                                  "**Restart the private bot for changes to take effect.** (Simulated)")
            else:
                await event.reply(f"» Bot `{bot_name}` not found in active bots.")
        else:
            await event.reply("» Usage: `.removebot <bot_name>`")
    else:
        await event.reply("» Only the owner can use this command.")

@X1.on(events.NewMessage(incoming=True, pattern=r"\%saddsudo(?: |$)(.*)" % hl))
async def addsudo(event):
    if event.sender_id == OWNER_ID:
        ok = await event.reply(f"» __ᴀᴅᴅɪɴɢ ᴜꜱᴇʀ ᴀꜱ ꜱᴜᴅᴏ...__")
        target_id = ""
        try:
            reply_msg = await event.get_reply_message()
            if reply_msg:
                target_id = reply_msg.sender_id
            else:
                cmd_args = event.text.split(" ", 1)
                if len(cmd_args) > 1 and cmd_args[1].isdigit():
                    target_id = int(cmd_args[1])
                elif len(cmd_args) > 1:
                    try:
                        entity = await event.client.get_entity(cmd_args[1])
                        target_id = entity.id
                    except Exception:
                        await ok.edit("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴜꜱᴇʀɴᴀᴍᴇ/ID !!")
                        return

        except Exception as e:
            await ok.edit(f"» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴜꜱᴇʀɴᴀᴍᴇ/ID !!\nError: {e}")
            return

        if not target_id:
            await ok.edit("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴜꜱᴇʀɴᴀᴍᴇ/ID !!")
            return

        if str(target_id) in [str(s_id) for s_id in SUDO_USERS]:
            await ok.edit(f"» `{target_id}` ɪꜱ ᴀʟʀᴇᴀᴅʏ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ.")
        else:
            SUDO_USERS.append(target_id)
            await ok.edit(f"» `{target_id}` ʜᴀꜱ ʙᴇᴇɴ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ᴀᴅᴅᴇᴅ ᴀꜱ ꜱᴜᴅᴏ ᴜꜱᴇʀ.\n**Restart the private bot for changes to take effect.** (Simulated)")
    else:
        await event.reply("» Only the owner can use this command.")


@X1.on(events.NewMessage(incoming=True, pattern=r"\%sremovesudo(?: |$)(.*)" % hl))
async def removesudo(event):
    if event.sender_id == OWNER_ID:
        ok = await event.reply(f"» __ʀᴇᴍᴏᴠɪɴɢ ᴜꜱᴇʀ ꜰʀᴏᴍ ꜱᴜᴅᴏ...__")
        target_id = ""
        try:
            reply_msg = await event.get_reply_message()
            if reply_msg:
                target_id = reply_msg.sender_id
            else:
                cmd_args = event.text.split(" ", 1)
                if len(cmd_args) > 1 and cmd_args[1].isdigit():
                    target_id = int(cmd_args[1])
                elif len(cmd_args) > 1:
                    try:
                        entity = await event.client.get_entity(cmd_args[1])
                        target_id = entity.id
                    except Exception:
                        await ok.edit("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴜꜱᴇʀɴᴀᴍᴇ/ID !!")
                        return
        except Exception as e:
            await ok.edit(f"» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴜꜱᴇʀɴᴀᴍᴇ/ID !!\nError: {e}")
            return

        if not target_id:
            await ok.edit("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴜꜱᴇʀɴᴀᴍᴇ/ID !!")
            return

        if str(target_id) not in [str(s_id) for s_id in SUDO_USERS]:
            await ok.edit(f"» `{target_id}` ɪꜱ ɴᴏᴛ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ.")
        else:
            SUDO_USERS.remove(target_id)
            await ok.edit(f"» `{target_id}` ʜᴀꜱ ʙᴇᴇɴ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ʀᴇᴍᴏᴠᴇᴅ ꜰʀᴏᴍ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ.\n**Restart the private bot for changes to take effect.** (Simulated)")
    else:
        await event.reply("» Only the owner can use this command.")