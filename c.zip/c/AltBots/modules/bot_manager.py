import asyncio
import json
import os
import sys

from telethon import events, TelegramClient
from config import X1, OWNER_ID, CMD_HNDLR as hl, BOT_TOKENS_FILE, API_ID, API_HASH, CLIENTS # Import necessary config variables

# Helper function to save BOT_TOKENS to file
def save_bot_tokens(tokens_list):
    with open(BOT_TOKENS_FILE, 'w') as f:
        json.dump(tokens_list, f)

@X1.on(events.NewMessage(incoming=True, pattern=r"\%saddbot(?: |$)(.*)" % hl))
async def add_new_bot(event):
    if event.sender_id == OWNER_ID:
        ok = await event.reply("» __Adding new bot...__")
        token_input = event.pattern_match.group(1).strip()

        if not token_input:
            await ok.edit("» Please provide a bot token. Usage: `.addbot <BOT_TOKEN>`")
            return

        # Load current tokens (should already be loaded in config, but for safety)
        current_tokens = []
        if os.path.exists(BOT_TOKENS_FILE):
            try:
                with open(BOT_TOKENS_FILE, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        current_tokens = data
            except json.JSONDecodeError:
                pass # Will proceed with empty list if file is corrupt or empty

        if token_input in current_tokens:
            await ok.edit("» This bot token is already added.")
            return

        current_tokens.append(token_input)
        save_bot_tokens(current_tokens)

        await ok.edit(f"» Successfully added new bot. Restarting to activate...")
        await asyncio.sleep(2)
        # This restart will re-read config.py and initialize the new client
        execl(sys.executable, sys.executable, *sys.argv)

@X1.on(events.NewMessage(incoming=True, pattern=r"\%sremovebot(?: |$)(.*)" % hl))
async def remove_existing_bot(event):
    if event.sender_id == OWNER_ID:
        ok = await event.reply("» __Removing bot...__")
        token_index_input = event.pattern_match.group(1).strip()

        if not token_index_input:
            await ok.edit("» Please provide the index of the bot to remove (e.g., `1` for the first bot, `2` for the second). Usage: `.removebot <INDEX>`")
            return

        try:
            index_to_remove = int(token_index_input) - 1 # Adjust for 0-based indexing
            if index_to_remove < 0:
                 await ok.edit("» Invalid index. Please provide a positive number.")
                 return

            current_tokens = []
            if os.path.exists(BOT_TOKENS_FILE):
                with open(BOT_TOKENS_FILE, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        current_tokens = data

            if index_to_remove >= len(current_tokens):
                await ok.edit("» Invalid bot index. No bot found at that position.")
                return

            removed_token = current_tokens.pop(index_to_remove)
            save_bot_tokens(current_tokens)

            await ok.edit(f"» Successfully removed bot. Restarting to apply changes...")
            await asyncio.sleep(2)
            # This restart will re-read config.py and remove the client
            execl(sys.executable, sys.executable, *sys.argv)

        except ValueError:
            await ok.edit("» Invalid index. Please provide a number.")
        except Exception as e:
            await ok.edit(f"Error removing bot: `{str(e)}`")

@X1.on(events.NewMessage(incoming=True, pattern=r"\%slivebots(?: |$)(.*)" % hl))
async def list_live_bots(event):
    if event.sender_id == OWNER_ID:
        active_bots_count = 0
        bot_list_msg = "» **Currently Active Bots:**\n"
        
        # CLIENTS list from config.py will contain only successfully started bots
        if not CLIENTS:
            bot_list_msg += "No bots are currently active."
        else:
            for i, client in enumerate(CLIENTS):
                if client and client.is_connected():
                    try:
                        me = await client.get_me()
                        bot_list_msg += f"{i+1}. @{me.username} (ID: `{me.id}`)\n"
                        active_bots_count += 1
                    except Exception as e:
                        bot_list_msg += f"{i+1}. (Error getting info: {e})\n"
                else:
                    bot_list_msg += f"{i+1}. (Not Connected or Failed to Start)\n"
            
            if active_bots_count == 0:
                bot_list_msg = "» No bots are currently active."

        await event.reply(bot_list_msg)