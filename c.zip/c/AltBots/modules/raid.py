import asyncio

from random import choice

from telethon import events

from config import ALL_CLIENTS, SUDO_USERS, OWNER_ID, CMD_HNDLR as hl
from AltBots.data import RAID, REPLYRAID, ALTRON, MRAID, SRAID, CRAID

REPLY_RAID = []

# Decorator for all clients
def on_all_clients(pattern):
    def decorator(func):
        for client in ALL_CLIENTS:
            client.on(events.NewMessage(incoming=True, pattern=pattern))(func)
        return func
    return decorator

@on_all_clients(pattern=r"\%sraid(?: |$)(.*)" % hl)
async def raid(e):
    if e.sender_id in SUDO_USERS:
        text = e.text.split(" ", 1)
        if len(text) == 2:
            count = int(text[1])
            if e.reply_to_msg_id:
                for _ in range(count):
                    await e.reply(choice(RAID))
                    await asyncio.sleep(0.1) # Small delay to prevent flood waits
            else:
                await e.reply("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴛᴏ ʀᴀɪᴅ ᴛʜᴇᴍ.")
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}raid <𝐜𝐨𝐮𝐧𝐭> <𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐮𝐬𝐞𝐫>")


@on_all_clients(pattern=r"\%sreplyraid(?: |$)(.*)" % hl)
async def replyraid(e):
    if e.sender_id in SUDO_USERS:
        if e.reply_to_msg_id:
            msg = await e.get_reply_message()
            user_id = msg.sender_id
            chat_id = e.chat_id
            check = f"{user_id}_{chat_id}"
            
            if check in REPLY_RAID:
                REPLY_RAID.remove(check)
                await e.reply("» ʀᴇᴘʟʏ ʀᴀɪᴅ ʜᴀꜱ ʙᴇᴇɴ ꜱᴛᴏᴘᴘᴇᴅ ꜰᴏʀ ᴛʜᴇ ᴜꜱᴇʀ !! ☑️")
            else:
                REPLY_RAID.append(check)
                await e.reply("» ʀᴇᴘʟʏ ʀᴀɪᴅ ʜᴀꜱ ʙᴇᴇɴ ꜱᴛᴀʀᴛᴇᴅ ꜰᴏʀ ᴛʜᴇ ᴜꜱᴇʀ !! ✅")
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}replyraid <𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐮𝐬𝐞𝐫>")


@ALL_CLIENTS[0].on(events.NewMessage(incoming=True)) # Only main bot monitors for reply raid
async def monitor_reply_raid(event):
    if event.sender_id == OWNER_ID:
        return
    if event.sender_id in SUDO_USERS:
        return
    
    check = f"{event.sender_id}_{event.chat_id}"
    if check in REPLY_RAID:
        try:
            await event.reply(choice(REPLYRAID))
        except:
            pass


@on_all_clients(pattern=r"\%smraid(?: |$)(.*)" % hl)
async def mraid(e):
    if e.sender_id in SUDO_USERS:
        text = e.text.split(" ", 1)
        if len(text) == 2:
            count = int(text[1])
            if e.reply_to_msg_id:
                for _ in range(count):
                    await e.reply(choice(MRAID))
                    await asyncio.sleep(0.1)
            else:
                await e.reply("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴛᴏ ᴍʀᴀɪᴅ ᴛʜᴇᴍ.")
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}mraid <𝐜𝐨𝐮𝐧𝐭> <𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐮𝐬𝐞𝐫>")


@on_all_clients(pattern=r"\%ssraid(?: |$)(.*)" % hl)
async def sraid(e):
    if e.sender_id in SUDO_USERS:
        text = e.text.split(" ", 1)
        if len(text) == 2:
            count = int(text[1])
            if e.reply_to_msg_id:
                for _ in range(count):
                    await e.reply(choice(SRAID))
                    await asyncio.sleep(0.1)
            else:
                await e.reply("» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴛᴏ ꜱʀᴀɪᴅ ᴛʜᴇᴍ.")
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}sraid <𝐜𝐨𝐮𝐧𝐭> <𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐮𝐬𝐞𝐫>")


@on_all_clients(pattern=r"\%scraid(?: |$)(.*)" % hl)
async def craid(e):
    if e.sender_id in SUDO_USERS:
        xraid = e.text.split(" ", 2)

        uid = None
        if len(xraid) == 3:
            try:
                entity = await e.client.get_entity(xraid[2])
                uid = entity.id
            except Exception:
                await e.reply("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀɴᴀᴍᴇ ᴏʀ ᴜꜱᴇʀ ɪᴅ.")
                return
        elif e.reply_to_msg_id:             
            a = await e.get_reply_message()
            try:
                entity = await e.client.get_entity(a.sender_id)
                uid = entity.id
            except Exception:
                await e.reply("» ᴄᴏᴜʟᴅ ɴᴏᴛ ɢᴇᴛ ᴜꜱᴇʀ ꜰʀᴏᴍ ʀᴇᴘʟɪᴇᴅ ᴍᴇꜱꜱᴀɢᴇ.")
                return
        else:
            await e.reply(f"» 𝐔𝐬𝐚𝐠𝐞: {hl}craid <𝐜𝐨𝐮𝐧𝐭> <𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐮𝐬𝐞𝐫 𝐨𝐫 𝐮𝐬𝐞𝐫𝐧𝐚𝐦𝐞/𝐢𝐝>")
            return

        if uid is None:
            await e.reply("» ɴᴏ ᴜꜱᴇʀ ꜰᴏᴜɴᴅ ᴛᴏ ᴄʀᴀɪᴅ.")
            return

        try:
            if uid in ALTRON:
                await e.reply("ɴᴏ, ᴛʜɪꜱ ɢᴜʏ ɪꜱ ᴀʟᴛʀᴏɴ'ꜱ ᴏᴡɴᴇʀ.")
            elif uid == OWNER_ID:
                await e.reply("ɴᴏ, ᴛʜɪꜱ ɢᴜʏ ɪꜱ ᴏᴡɴᴇʀ ᴏꜰ ᴛʜᴇꜱᴇ ʙᴏᴛꜱ.")
            elif uid in SUDO_USERS:
                await e.reply("ɴᴏ, ᴛʜɪꜱ ɢᴜʏ ɪꜱ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ.")
            else:
                first_name = entity.first_name
                counter = int(xraid[1])
                username = f"[{first_name}](tg://user?id={uid})"

                for _ in range(counter):
                    await e.client.send_message(e.chat_id, choice(CRAID).format(username))
                    await asyncio.sleep(0.1)
        except Exception as ex:
            await e.reply(f"ᴇʀʀᴏʀ: {ex}")