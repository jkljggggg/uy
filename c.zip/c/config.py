import logging

from telethon import TelegramClient

from os import getenv
from AltBots.data import ALTRON


logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=logging.WARNING)


# VALUES REQUIRED FOR XBOTS
API_ID = 27494996
API_HASH = "791274de917e999ebab112e60f3a163e"
CMD_HNDLR = getenv("CMD_HNDLR", default=".")

BOT_TOKEN = getenv("BOT_TOKEN", default=None)

SUDO_USERS = list(map(lambda x: int(x), getenv("SUDO_USERS", default="7681062358").split()))
for x in ALTRON:
    SUDO_USERS.append(x)
OWNER_ID = int(getenv("OWNER_ID", default="7681062358"))
SUDO_USERS.append(OWNER_ID)


# ------------- CLIENTS -------------

# X1 will be initialized but not started here
X1 = TelegramClient('X1', API_ID, API_HASH)