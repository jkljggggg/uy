import logging
from telethon import TelegramClient
from os import getenv
from AltBots.data import ALTRON # Assuming ALTRON is a list of IDs
import json # Import json module
import os # Import os module to check for file existence

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=logging.WARNING)

# VALUES REQUIRED FOR XBOTS
API_ID = 27494996
API_HASH = "791274de917e999ebab112e60f3a163e"
CMD_HNDLR = getenv("CMD_HNDLR", default=".")

# --- File paths for persistence ---
BOT_TOKENS_FILE = "bot_tokens.json"
SUDO_USERS_FILE = "sudo_users.json"

# --- Load bot tokens from JSON file ---
BOT_TOKENS = []
if os.path.exists(BOT_TOKENS_FILE):
    try:
        with open(BOT_TOKENS_FILE, 'r') as f:
            data = json.load(f)
            if isinstance(data, list):
                BOT_TOKENS = data
            else:
                logging.warning(f"Invalid format in {BOT_TOKENS_FILE}. Expected a list.")
    except json.JSONDecodeError:
        logging.error(f"Error decoding JSON from {BOT_TOKENS_FILE}. Starting with empty tokens.")
else:
    # If file doesn't exist, try to load initial BOT_TOKEN from env (for first run)
    initial_token = getenv("BOT_TOKEN", default=None)
    if initial_token:
        BOT_TOKENS.append(initial_token)
        with open(BOT_TOKENS_FILE, 'w') as f:
            json.dump(BOT_TOKENS, f)
        logging.info("Initialized bot_tokens.json from BOT_TOKEN environment variable.")

# --- Load sudo users from JSON file ---
SUDO_USERS = []
if os.path.exists(SUDO_USERS_FILE):
    try:
        with open(SUDO_USERS_FILE, 'r') as f:
            data = json.load(f)
            # Ensure loaded data is a list of integers
            if isinstance(data, list) and all(isinstance(x, int) for x in data):
                SUDO_USERS = data
            else:
                logging.warning(f"Invalid format in {SUDO_USERS_FILE}. Expected a list of integers.")
                SUDO_USERS = [] # Reset to empty if invalid
    except json.JSONDecodeError:
        logging.error(f"Error decoding JSON from {SUDO_USERS_FILE}. Starting with default sudo users.")
else:
    # If file doesn't exist, try to load initial SUDO_USERS from env (for first run)
    initial_sudo_env = getenv("SUDO_USERS", default="7681062358")
    SUDO_USERS = list(map(lambda x: int(x), initial_sudo_env.split()))
    with open(SUDO_USERS_FILE, 'w') as f:
        json.dump(SUDO_USERS, f)
    logging.info("Initialized sudo_users.json from SUDO_USERS environment variable.")


# Add ALTRON users and OWNER_ID to SUDO_USERS if they are not already there
OWNER_ID = int(getenv("OWNER_ID", default="7681062358")) # Still get OWNER_ID from env
if OWNER_ID not in SUDO_USERS:
    SUDO_USERS.append(OWNER_ID)
for x in ALTRON:
    if x not in SUDO_USERS:
        SUDO_USERS.append(x)


# Save initial sudo users to file after ensuring owner/altron are included
# This ensures that even if the file didn't exist, it's created correctly
with open(SUDO_USERS_FILE, 'w') as f:
    json.dump(SUDO_USERS, f)


# ------------- CLIENTS -------------
# Initialize clients based on BOT_TOKENS list
X1, X2, X3, X4, X5, X6, X7, X8, X9, X10 = [None] * 10 # Initialize with None
clients_raw = []
for i, token in enumerate(BOT_TOKENS):
    try:
        client = TelegramClient(f'X{i+1}', API_ID, API_HASH).start(bot_token=token)
        clients_raw.append(client)
        if i == 0: X1 = client
        elif i == 1: X2 = client
        elif i == 2: X3 = client
        elif i == 3: X4 = client
        elif i == 4: X5 = client
        elif i == 5: X6 = client
        elif i == 6: X7 = client
        elif i == 7: X8 = client
        elif i == 8: X9 = client
        elif i == 9: X10 = client
    except Exception as e:
        logging.error(f"Error starting client X{i+1} with token (first few chars): {token[:5]}...: {e}")
        # If a client fails to start, its corresponding X variable will remain None
        # and it won't be added to clients_raw. This is intentional.

CLIENTS = clients_raw # This list will contain only successfully started clients