import logging
import asyncio # Added for run_until_disconnected in dynamic client creation

from telethon import TelegramClient

from os import getenv
from AltBots.data import ALTRON

# Import database functions
from database import init_db, get_bot_tokens, get_sudo_users, add_bot_token as db_add_bot_token, remove_bot_token as db_remove_bot_token, add_sudo_user as db_add_sudo_user, remove_sudo_user as db_remove_sudo_user

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=logging.WARNING)


# VALUES REQUIRED FOR XBOTS
API_ID = 27494996
API_HASH = "791274de917e999ebab112e60f3a163e"
CMD_HNDLR = getenv("CMD_HNDLR", default=".")

# Initialize the database
init_db()

# Main Bot Token (can still be from env or hardcoded if preferred for the main bot)
BOT_TOKEN = getenv("BOT_TOKEN", default=None)

# Load additional bot tokens from the database
ADDITIONAL_BOT_TOKENS = get_bot_tokens()

# Load sudo users from the database
SUDO_USERS = get_sudo_users()

# Add ALTRON users and OWNER_ID to SUDO_USERS (only if not already present)
for x in ALTRON:
    if x not in SUDO_USERS:
        SUDO_USERS.append(x)
OWNER_ID = int(getenv("OWNER_ID", default="7681062358"))
if OWNER_ID not in SUDO_USERS:
    SUDO_USERS.append(OWNER_ID)


# ------------- CLIENTS -------------

# Main bot client
X1 = TelegramClient('X1', API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# Dynamic creation of additional bot clients
ADDITIONAL_CLIENTS = []
async def start_additional_clients():
    for i, token in enumerate(ADDITIONAL_BOT_TOKENS):
        try:
            # Check if client already exists before starting
            client_exists = False
            for client in ADDITIONAL_CLIENTS:
                if client.is_connected() and client.me and client.me.bot and client.me.bot_token == token:
                    client_exists = True
                    break
            if client_exists:
                continue # Skip if client with this token is already running

            client = TelegramClient(f'X{i+2}', API_ID, API_HASH)
            await client.start(bot_token=token)
            ADDITIONAL_CLIENTS.append(client)
            logging.info(f"Started additional bot with token {token[:5]}...")
        except Exception as e:
            logging.warning(f"Failed to start bot with token {token[:5]}...: {e}")

# This part ensures clients are started when config is loaded, but run_until_disconnected will be in main.py
loop = asyncio.get_event_loop()
loop.run_until_complete(start_additional_clients())

# Combine all clients for easier iteration in other files
ALL_CLIENTS = [X1] + ADDITIONAL_CLIENTS

# Expose database functions for external use (e.g., in bot.py)
add_bot_token = db_add_bot_token
remove_bot_token = db_remove_bot_token
add_sudo_user = db_add_sudo_user
remove_sudo_user = db_remove_sudo_user