import logging
from telethon import TelegramClient
from os import getenv, path
import json

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=logging.WARNING)

API_ID = 27494996
API_HASH = "791274de917e999ebab112e60f3a163e"
CMD_HNDLR = getenv("CMD_HNDLR", default=".") # Command handler (e.g., '.')

# Owner ID (Telegram User ID of the bot owner)
# Replace with your actual Telegram User ID
OWNER_ID = int(getenv("OWNER_ID", "123456789")) # IMPORTANT: Replace 123456789 with your actual Telegram User ID

# Sudo Users File
SUDO_USERS_FILE = "sudo_users.json"
BOT_TOKENS_FILE = "bot_tokens.json"

# Load SUDO_USERS from file
SUDO_USERS = []
if path.exists(SUDO_USERS_FILE):
    with open(SUDO_USERS_FILE, "r") as f:
        try:
            SUDO_USERS = json.load(f)
        except json.JSONDecodeError:
            SUDO_USERS = []

# Ensure OWNER_ID is always in SUDO_USERS
if OWNER_ID not in SUDO_USERS:
    SUDO_USERS.append(OWNER_ID)
    with open(SUDO_USERS_FILE, "w") as f:
        json.dump(sorted(list(set(SUDO_USERS))), f)


# Load BOT_TOKENS from file
BOT_TOKENS = []
if path.exists(BOT_TOKENS_FILE):
    with open(BOT_TOKENS_FILE, "r") as f:
        try:
            BOT_TOKENS = json.load(f)
        except json.JSONDecodeError:
            BOT_TOKENS = []

# If BOT_TOKENS_FILE is empty and BOT_TOKEN is provided as an env var, add it
initial_bot_token_env = getenv("BOT_TOKEN", default=None)
if not BOT_TOKENS and initial_bot_token_env:
    BOT_TOKENS.append(initial_bot_token_env)
    with open(BOT_TOKENS_FILE, "w") as f:
        json.dump(BOT_TOKENS, f) # Save the initial token


# ------------- CLIENTS -------------
CLIENTS = [] # This list will hold all active TelegramClient objects

async def initialize_clients():
    global CLIENTS
    CLIENTS = [] # Clear existing clients
    for i, token in enumerate(BOT_TOKENS):
        try:
            client_name = f'X{i+1}' # Assign a name like X1, X2, etc.
            client = TelegramClient(client_name, API_ID, API_HASH)
            await client.start(bot_token=token)
            CLIENTS.append(client)
            logging.info(f"Started client: {client_name} (ID: {client.loop.run_until_complete(client.get_me()).id})")
        except Exception as e:
            logging.error(f"Failed to start client with token index {i+1}: {e}")

    if not CLIENTS:
        logging.error("No bot tokens provided or failed to start any client. Exiting.")
        exit(1)

    # For backward compatibility with existing plugin files that might reference X1, X2 etc.
    # This is less ideal, but necessary if the plugins aren't fully refactored.
    # It's better to iterate CLIENTS in plugins, but this provides a fallback.
    globals()['X1'] = CLIENTS[0] if len(CLIENTS) > 0 else None
    globals()['X2'] = CLIENTS[1] if len(CLIENTS) > 1 else None
    globals()['X3'] = CLIENTS[2] if len(CLIENTS) > 2 else None
    globals()['X4'] = CLIENTS[3] if len(CLIENTS) > 3 else None
    globals()['X5'] = CLIENTS[4] if len(CLIENTS) > 4 else None
    globals()['X6'] = CLIENTS[5] if len(CLIENTS) > 5 else None
    globals()['X7'] = CLIENTS[6] if len(CLIENTS) > 6 else None
    globals()['X8'] = CLIENTS[7] if len(CLIENTS) > 7 else None
    globals()['X9'] = CLIENTS[8] if len(CLIENTS) > 8 else None
    globals()['X10'] = CLIENTS[9] if len(CLIENTS) > 9 else None
    # For more than 10, plugins MUST iterate CLIENTS.