import sys
import glob
import asyncio
import logging
import importlib
import urllib3
from pathlib import Path

# Import only CLIENTS and the new initialize_clients function
from config import CLIENTS, initialize_clients, CMD_HNDLR

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s', level=logging.WARNING)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Store loaded plugins to avoid re-importing
LOADED_PLUGINS = {}

def load_plugins():
    global LOADED_PLUGINS
    files = glob.glob("AltBots/modules/*.py")
    for name in files:
        with open(name) as a:
            patt = Path(a.name)
            plugin_name = patt.stem
            if plugin_name == "__init__":
                continue
            if plugin_name not in LOADED_PLUGINS:
                path = Path(f"AltBots/modules/{plugin_name}.py")
                spec = importlib.util.spec_from_file_location(f"AltBots.modules.{plugin_name}", path)
                load = importlib.util.module_from_spec(spec)
                load.logger = logging.getLogger(plugin_name)
                spec.loader.exec_module(load)
                sys.modules["AltBots.modules." + plugin_name] = load
                LOADED_PLUGINS[plugin_name] = load # Store the loaded module
                print("Altron has Imported " + plugin_name)

print("\n𝐗𝐁𝐨𝐭𝐬 𝐃𝐞𝐩𝐥𝐨𝐲𝐞𝐝 𝐒𝐮𝐜𝐜𝐞𝐬𝐬𝐟𝐮𝐥𝐥𝐲 ⚡\nMy Master ---> @rajaraj909")

async def main():
    await initialize_clients() # Initialize clients here

    # After clients are initialized, load plugins and register handlers
    # This step is crucial because plugins need the client objects (X1, X2, etc.) to be ready.
    load_plugins()

    if CLIENTS:
        tasks = [client.run_until_disconnected() for client in CLIENTS]
        await asyncio.gather(*tasks)
    else:
        logging.error("No active clients found to run. Please check your BOT_TOKEN(s) in bot_tokens.json or env.")

if __name__ == "__main__":
    asyncio.run(main())