from telethon import events
from config import CLIENTS, SUDO_USERS, OWNER_ID, CMD_HNDLR

def register_message_handlers(pattern, incoming=True, outgoing=False):
    def decorator(func):
        async def wrapper(event):
            # Check if the sender is authorized (sudo user or owner)
            # This check can be moved inside each handler if specific permissions are needed
            # For now, let's keep it broad for simplicity if you want all sudo users to use all commands
            if event.sender_id in SUDO_USERS:
                await func(event)
            else:
                await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ ᴄᴀɴ ᴜꜱᴇ ᴛʜɪꜱ.")
        
        # Register the handler for all currently active clients
        for client in CLIENTS:
            client.add_event_handler(wrapper, events.NewMessage(pattern=pattern, incoming=incoming, outgoing=outgoing))
        return wrapper
    return decorator

def register_callback_query_handlers(pattern):
    def decorator(func):
        async def wrapper(event):
            if event.query.user_id in SUDO_USERS:
                await func(event)
            else:
                await event.answer("Make Your Own Altron Bots !! @RAJARAJ909", cache_time=0, alert=True)
        
        # Register the handler for all currently active clients
        for client in CLIENTS:
            client.add_event_handler(wrapper, events.CallbackQuery(pattern=pattern))
        return wrapper
    return decorator