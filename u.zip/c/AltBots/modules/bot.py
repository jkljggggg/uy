import sys
from config import SUDO_USERS, OWNER_ID, CMD_HNDLR as hl, SUDO_USERS_FILE, BOT_TOKENS_FILE, BOT_TOKENS, initialize_clients, CLIENTS
from os import execl
from telethon import events
from datetime import datetime
import asyncio
import json

# Import the new decorators
# Assuming AltBots/utils/decorators.py exists
from AltBots.utils.decorators import register_message_handlers, register_callback_query_handlers

# Function to save sudo users to file
def save_sudo_users():
    with open(SUDO_USERS_FILE, "w") as f:
        json.dump(sorted(list(set(SUDO_USERS))), f, indent=4)

# Function to save bot tokens to file
def save_bot_tokens():
    with open(BOT_TOKENS_FILE, "w") as f:
        json.dump(BOT_TOKENS, f, indent=4)

@register_message_handlers(pattern=r"\%sping(?: |$)(.*)" % hl)
async def ping(event):
    # Sudo check is already handled by the decorator's wrapper function
    start_time = datetime.now()
    await event.reply("ᴘᴏɴɢ❗")
    end_time = datetime.now()
    ping_time = (end_time - start_time).microseconds / 1000
    await event.edit(f"ᴘᴏɴɢ❗ `{ping_time}ms`")


@register_message_handlers(pattern=r"\%saddsudo(?: |$)(.*)" % hl)
async def addsudo(event):
    # Ensure only OWNER_ID can use this command
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ᴀᴅᴅ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ.")
        return

    ok = await event.reply("» ᴘʀᴏᴄᴇꜱꜱɪɴɢ...")
    user_id = None
    user_name = None

    if event.reply_to_msg_id:
        reply_message = await event.get_reply_message()
        user_id = reply_message.sender_id
        user_name = reply_message.sender.first_name
    elif event.pattern_match.group(1):
        user_input = event.pattern_match.group(1).strip()
        try:
            user_id = int(user_input)
            user = await event.client.get_entity(user_id)
            user_name = user.first_name
        except ValueError:
            try:
                user = await event.client.get_entity(user_input)
                user_id = user.id
                user_name = user.first_name
            except Exception:
                await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ᴜꜱᴇʀɴᴀᴍᴇ.")
                return
        except Exception:
            await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ᴜꜱᴇʀɴᴀᴍᴇ.")
            return
    else:
        await ok.edit(f"» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ɢɪᴠᴇ ᴛʜᴇɪʀ ᴜꜱᴇʀ ɪᴅ/ᴜꜱᴇʀɴᴀᴍᴇ ᴛᴏ ᴀᴅᴅ ᴀꜱ ꜱᴜᴅᴏ.")
        return

    if user_id in SUDO_USERS:
        await ok.edit(f"» [{user_name}](tg://user?id={user_id}) ɪꜱ ᴀʟʀᴇᴀᴅʏ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ.")
    else:
        SUDO_USERS.append(user_id)
        save_sudo_users()
        await ok.edit(f"» [{user_name}](tg://user?id={user_id}) ʜᴀꜱ ʙᴇᴇɴ ᴀᴅᴅᴇᴅ ᴀꜱ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ. ✅")


@register_message_handlers(pattern=r"\%sdelsudo(?: |$)(.*)" % hl)
async def delsudo(event):
    # Ensure only OWNER_ID can use this command
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ʀᴇᴍᴏᴠᴇ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ.")
        return

    ok = await event.reply("» ᴘʀᴏᴄᴇꜱꜱɪɴɢ...")
    user_id = None
    user_name = None

    if event.reply_to_msg_id:
        reply_message = await event.get_reply_message()
        user_id = reply_message.sender_id
        user_name = reply_message.sender.first_name
    elif event.pattern_match.group(1):
        user_input = event.pattern_match.group(1).strip()
        try:
            user_id = int(user_input)
            user = await event.client.get_entity(user_id)
            user_name = user.first_name
        except ValueError:
            try:
                user = await event.client.get_entity(user_input)
                user_id = user.id
                user_name = user.first_name
            except Exception:
                await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ᴜꜱᴇʀɴᴀᴍᴇ.")
                return
        except Exception:
            await ok.edit("» ɪɴᴠᴀʟɪᴅ ᴜꜱᴇʀ ɪᴅ ᴏʀ ᴜꜱᴇʀɴᴀᴍᴇ.")
            return
    else:
        await ok.edit(f"» ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴜꜱᴇʀ ᴏʀ ɢɪᴠᴇ ᴛʜᴇɪʀ ᴜꜱᴇʀ ɪᴅ/ᴜꜱᴇʀɴᴀᴍᴇ ᴛᴏ ʀᴇᴍᴏᴠᴇ ᴀꜱ ꜱᴜᴅᴏ.")
        return

    if user_id == OWNER_ID:
        await ok.edit("» ʏᴏᴜ ᴄᴀɴɴᴏᴛ ʀᴇᴍᴏᴠᴇ ᴛʜᴇ ᴏᴡɴᴇʀ ꜰʀᴏᴍ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ.")
    elif user_id not in SUDO_USERS:
        await ok.edit(f"» [{user_name}](tg://user?id={user_id}) ɪꜱ ɴᴏᴛ ᴀ ꜱᴜᴅᴏ ᴜꜱᴇʀ.")
    else:
        SUDO_USERS.remove(user_id)
        save_sudo_users()
        await ok.edit(f"» [{user_name}](tg://user?id={user_id}) ʜᴀꜱ ʙᴇᴇɴ ʀᴇᴍᴏᴠᴇᴅ ꜰʀᴏᴍ ꜱᴜᴅᴏ ᴜꜱᴇʀꜱ. ✅")


@register_message_handlers(pattern=r"\%srestart(?: |$)(.*)" % hl)
async def restart(event):
    if event.sender_id == OWNER_ID:
        ok = await event.reply("» ʀᴇꜱᴛᴀʀᴛɪɴɢ...")
        try:
            execl(sys.executable, sys.executable, __file__) # Local restart
        except Exception as e:
            await ok.edit(f"» ꜰᴀɪʟᴇᴅ ᴛᴏ ʀᴇꜱᴛᴀʀᴛ: `{str(e)}`")
    else:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ʀᴇꜱᴛᴀʀᴛ ᴛʜᴇ ʙᴏᴛ.")


@register_message_handlers(pattern=r"\%saddbot(?: |$)(.*)" % hl)
async def add_bot_token(event):
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ᴀᴅᴅ ʙᴏᴛꜱ.")
        return

    token = event.pattern_match.group(1).strip()
    if not token:
        await event.reply("» ᴘʟᴇᴀꜱᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ʙᴏᴛ ᴛᴏᴋᴇɴ.")
        return

    if token in BOT_TOKENS:
        await event.reply("» ᴛʜɪꜱ ʙᴏᴛ ᴛᴏᴋᴇɴ ɪꜱ ᴀʟʀᴇᴀᴅʏ ᴀᴅᴅᴇᴅ.")
        return

    BOT_TOKENS.append(token)
    save_bot_tokens()
    await event.reply("» ʙᴏᴛ ᴛᴏᴋᴇɴ ᴀᴅᴅᴇᴅ. ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛ ᴛᴏ ᴀᴘᴘʟʏ ᴄʜᴀɴɢᴇꜱ...")
    await asyncio.sleep(2) # Give some time for message to send
    try:
        execl(sys.executable, sys.executable, __file__) # Local restart
    except Exception as e:
        await event.reply(f"» ꜰᴀɪʟᴇᴅ ᴛᴏ ʀᴇꜱᴛᴀʀᴛ: `{str(e)}`")


@register_message_handlers(pattern=r"\%sdelbot(?: |$)(.*)" % hl)
async def del_bot_token(event):
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ʀᴇᴍᴏᴠᴇ ʙᴏᴛꜱ.")
        return

    token_or_index = event.pattern_match.group(1).strip()
    if not token_or_index:
        await event.reply("» ᴘʟᴇᴀꜱᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ʙᴏᴛ ᴛᴏᴋᴇɴ ᴏʀ ɪɴᴅᴇx ᴛᴏ ʀᴇᴍᴏᴠᴇ. Use `.listbots` to see indices.")
        return

    removed_count = 0
    updated_tokens = []
    
    # Try removing by exact token match first
    if token_or_index in BOT_TOKENS:
        BOT_TOKENS.remove(token_or_index)
        save_bot_tokens()
        await event.reply(f"» ʙᴏᴛ ᴛᴏᴋᴇɴ ʀᴇᴍᴏᴠᴇᴅ. ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛ ᴛᴏ ᴀᴘᴘʟʏ ᴄʜᴀɴɢᴇꜱ...")
        removed_count += 1
    else:
        # Try removing by index
        try:
            index_to_remove = int(token_or_index) - 1 # User sees 1-based index
            if 0 <= index_to_remove < len(BOT_TOKENS):
                removed_token = BOT_TOKENS.pop(index_to_remove)
                save_bot_tokens()
                await event.reply(f"» ʙᴏᴛ (ɪɴᴅᴇx {index_to_remove + 1}) ᴡɪᴛʜ ᴛᴏᴋᴇɴ `{removed_token[:5]}...` ʀᴇᴍᴏᴠᴇᴅ. ʀᴇꜱᴛᴀʀᴛɪɴɢ ʙᴏᴛ ᴛᴏ ᴀᴘᴘʟʏ ᴄʜᴀɴɢᴇꜱ...")
                removed_count += 1
            else:
                await event.reply("» ɪɴᴠᴀʟɪᴅ ʙᴏᴛ ɪɴᴅᴇx.")
        except ValueError:
            await event.reply("» ɪɴᴠᴀʟɪᴅ ʙᴏᴛ ᴛᴏᴋᴇɴ ᴏʀ ɪɴᴅᴇx. ᴘʟᴇᴀꜱᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴠᴀʟɪᴅ ᴛᴏᴋᴇɴ ᴏʀ ɪɴᴅᴇx.")

    if removed_count > 0:
        await asyncio.sleep(2)
        try:
            execl(sys.executable, sys.executable, __file__) # Local restart
        except Exception as e:
            await event.reply(f"» ꜰᴀɪʟᴇᴅ ᴛᴏ ʀᴇꜱᴛᴀʀᴛ: `{str(e)}`")
    elif removed_count == 0:
        await event.reply("» ʙᴏᴛ ᴛᴏᴋᴇɴ ᴏʀ ɪɴᴅᴇx ɴᴏᴛ ꜰᴏᴜɴᴅ.")


@register_message_handlers(pattern=r"\%slistbots(?: |$)(.*)" % hl)
async def list_bots(event):
    if event.sender_id != OWNER_ID:
        await event.reply("» ʏᴏᴜ ᴀʀᴇ ɴᴏᴛ ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ᴄᴏᴍᴍᴀɴᴅ. ᴏɴʟʏ ᴛʜᴇ `ᴏᴡɴᴇʀ_ɪᴅ` ᴄᴀɴ ʟɪꜱᴛ ʙᴏᴛꜱ.")
        return

    if not BOT_TOKENS:
        await event.reply("» ɴᴏ ʙᴏᴛ ᴛᴏᴋᴇɴꜱ ᴀʀᴇ ᴄᴏɴꜰɪɢᴜʀᴇᴅ.")
        return

    message = "**★ ᴄᴏɴꜰɪɢᴜʀᴇᴅ ʙᴏᴛ ᴛᴏᴋᴇɴꜱ: ★**\n\n"
    for i, token in enumerate(BOT_TOKENS):
        try:
            client_id = CLIENTS[i].loop.run_until_complete(CLIENTS[i].get_me()).id if i < len(CLIENTS) else "N/A"
            message += f"**{i+1}.** Token: `{token[:5]}...` | Client ID: `{client_id}`\n"
        except Exception:
             message += f"**{i+1}.** Token: `{token[:5]}...` | Client ID: `Failed to get ID`\n"

    await event.reply(message)